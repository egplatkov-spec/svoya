"""Ресепшен: QR-пропуск ведёт на /admin/checkin/<код>, там виден статус и кнопка «Отметить визит»."""
from datetime import time, timedelta

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from sqlalchemy.orm import Session

from app.core import clock
from app.core.flash import flash
from app.db.session import get_db
from app.models import User
from app.services import checkin, users
from app.web.deps import redirect, require_admin
from app.web.templating import render

router = APIRouter(prefix="/checkin")


@router.get("")
def checkin_home(request: Request, q: str = "", db: Session = Depends(get_db)):
    today_start = clock.at(clock.today(), time(0, 0))
    found = users.search(db, q, limit=20) if q.strip() else []
    return render(request, "admin/checkin.html", section="checkin", q=q, found=found,
                  visits=checkin.visits_between(db, today_start, today_start + timedelta(days=1)))


@router.post("/code")
def by_code(code: str = Form("")):
    code = code.strip().rstrip("/").rsplit("/", 1)[-1]  # можно вставить и код, и ссылку целиком
    return redirect(f"/admin/checkin/{code}" if code else "/admin/checkin")


@router.get("/{code}")
def pass_view(request: Request, code: str, db: Session = Depends(get_db)):
    user = checkin.find_by_code(db, code)
    if user is None:
        raise HTTPException(404, "Пропуск не найден или был перевыпущен")
    return render(request, "admin/checkin_pass.html", section="checkin", result=checkin.check(db, user))


@router.post("/{code}")
def pass_register(request: Request, code: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = checkin.find_by_code(db, code)
    if user is None:
        raise HTTPException(404, "Пропуск не найден")
    checkin.register_visit(db, user, admin)
    flash(request, f"Визит отмечен: {user.name}")
    return redirect("/admin/checkin")
