"""Групповые занятия по дням: сколько записано, список и отметка присутствия."""
from datetime import date, timedelta

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from sqlalchemy.orm import Session

from app.core import clock
from app.core.flash import flash
from app.db.session import get_db
from app.models import Booking, ScheduleSlot
from app.services import bookings
from app.web.deps import redirect
from app.web.templating import render

router = APIRouter(prefix="/classes")


@router.get("")
def by_day(request: Request, day: date | None = None, db: Session = Depends(get_db)):
    day = day or clock.today()
    return render(request, "admin/classes.html", section="classes", day=day,
                  occurrences=bookings.occurrences(db, day, 1)[day],
                  prev_day=day - timedelta(days=1), next_day=day + timedelta(days=1))


@router.get("/{slot_id}/{day}")
def roster(request: Request, slot_id: int, day: date, db: Session = Depends(get_db)):
    slot = db.get(ScheduleSlot, slot_id)
    if slot is None:
        raise HTTPException(404, "Занятие не найдено")
    return render(request, "admin/roster.html", section="classes", slot=slot, day=day,
                  bookings=bookings.roster(db, slot_id, day), starts_at=clock.at(day, slot.start_time))


@router.post("/attendance/{booking_id}")
def attendance(request: Request, booking_id: int, attended: bool = Form(False), db: Session = Depends(get_db)):
    b = db.get(Booking, booking_id)
    if b is None:
        raise HTTPException(404, "Запись не найдена")
    bookings.set_attendance(db, b, attended)
    flash(request, f"{b.user.name}: {'пришла' if attended else 'не пришла'}")
    return redirect(f"/admin/classes/{b.slot_id}/{b.class_date.isoformat()}")
