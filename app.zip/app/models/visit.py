from datetime import datetime

from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.db.types import UTCDateTime, utcnow


class Visit(Base):
    """Отметка прихода в клуб (по QR-пропуску или вручную на ресепшене)."""

    __tablename__ = "visits"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    membership_id: Mapped[int | None] = mapped_column(ForeignKey("memberships.id"), default=None)
    admin_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), default=None)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)

    user: Mapped["User"] = relationship(foreign_keys=[user_id])  # noqa: F821
