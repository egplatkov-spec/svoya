"""Абонементы: выдача, очередь из нескольких абонементов, заморозка, аннулирование.

Правила:
* абонементы клиентки идут друг за другом: новый начинается на следующий день после окончания текущего;
* заморозка продлевает абонемент на число дней заморозки и сдвигает следующие абонементы;
* записи на групповые занятия в дни, когда абонемент не действует, автоматически отменяются.
"""
from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core import clock
from app.core.errors import DomainError
from app.models import Booking, BookingStatus, Freeze, Membership, MembershipState, Order, Product, ProductKind


def user_memberships(db: Session, user_id: int, include_cancelled: bool = False) -> list[Membership]:
    q = select(Membership).where(Membership.user_id == user_id)
    if not include_cancelled:
        q = q.where(Membership.is_cancelled.is_(False))
    return list(db.scalars(q.order_by(Membership.start_date)))


def membership_on(db: Session, user_id: int, d: date) -> Membership | None:
    """Абонемент, период которого покрывает дату (в т.ч. замороженный)."""
    return next((m for m in user_memberships(db, user_id) if m.start_date <= d <= m.end_date), None)


def active_on(db: Session, user_id: int, d: date) -> Membership | None:
    m = membership_on(db, user_id, d)
    return m if m and m.state_on(d) == MembershipState.active else None


def current_or_next(db: Session, user_id: int) -> Membership | None:
    """Что показать в кабинете: текущий абонемент, а если его нет — ближайший будущий."""
    today = clock.today()
    return next((m for m in user_memberships(db, user_id) if m.end_date >= today), None)


def queued_after(db: Session, m: Membership) -> list[Membership]:
    return [x for x in user_memberships(db, m.user_id) if x.id != m.id and x.start_date > m.start_date]


def next_start_date(db: Session, user_id: int) -> date:
    today = clock.today()
    ends = [m.end_date for m in user_memberships(db, user_id) if m.end_date >= today]
    return max(ends) + timedelta(days=1) if ends else today


def create_membership(db: Session, order: Order) -> Membership:
    existing = db.scalar(select(Membership).where(Membership.order_id == order.id))
    if existing:
        return existing
    product: Product = order.product
    if product.kind != ProductKind.membership or not product.duration_days:
        raise DomainError("Этот товар не является абонементом")
    start = next_start_date(db, order.user_id)
    m = Membership(
        user_id=order.user_id, order_id=order.id, product_id=product.id,
        start_date=start, end_date=start + timedelta(days=product.duration_days - 1),
        freeze_days_allowed=product.freeze_days,
    )
    db.add(m)
    db.flush()
    return m


def _shift(db: Session, memberships: list[Membership], delta: int) -> None:
    if not delta:
        return
    shift = timedelta(days=delta)
    for m in memberships:
        m.start_date += shift
        m.end_date += shift
        for f in m.freezes:
            f.start_date += shift
            f.end_date += shift


def drop_uncovered_bookings(db: Session, user_id: int) -> int:
    """Отменяет будущие записи на даты, когда у клиентки нет действующего абонемента."""
    today = clock.today()
    bookings = db.scalars(
        select(Booking).where(
            Booking.user_id == user_id, Booking.status == BookingStatus.booked, Booking.class_date >= today
        )
    ).all()
    dropped = 0
    for b in bookings:
        if active_on(db, user_id, b.class_date) is None:
            b.status = BookingStatus.cancelled
            dropped += 1
    return dropped


def freeze(db: Session, m: Membership, start: date, days: int) -> Freeze:
    today = clock.today()
    if m.is_cancelled or m.end_date < today:
        raise DomainError("Этот абонемент уже не действует")
    if days < 1:
        raise DomainError("Укажите хотя бы один день заморозки")
    if days > m.freeze_days_left:
        raise DomainError(f"Доступно дней заморозки: {m.freeze_days_left}")
    if start < today:
        raise DomainError("Заморозку нельзя начать в прошлом")
    if not (m.start_date <= start <= m.end_date):
        raise DomainError("Дата начала заморозки должна попадать в срок абонемента")
    end = start + timedelta(days=days - 1)
    for f in m.freezes:
        if f.start_date <= end and start <= f.end_date:
            raise DomainError("Заморозка пересекается с уже назначенной")

    later = queued_after(db, m)
    fr = Freeze(start_date=start, end_date=end)
    m.freezes.append(fr)
    m.end_date += timedelta(days=days)
    _shift(db, later, days)
    db.flush()
    drop_uncovered_bookings(db, m.user_id)
    db.commit()
    return fr


def cancel_freeze(db: Session, fr: Freeze) -> None:
    """Будущую заморозку отменяет полностью, текущую — завершает вчерашним днём."""
    today = clock.today()
    m = fr.membership
    if fr.end_date < today:
        raise DomainError("Эта заморозка уже закончилась")
    later = queued_after(db, m)
    if fr.start_date >= today:
        returned = fr.days
        m.freezes.remove(fr)
    else:
        returned = (fr.end_date - today).days + 1
        fr.end_date = today - timedelta(days=1)
    m.end_date -= timedelta(days=returned)
    _shift(db, later, -returned)
    db.flush()
    drop_uncovered_bookings(db, m.user_id)
    db.commit()


def cancel_membership(db: Session, m: Membership) -> None:
    """Аннулирует абонемент (например, при возврате денег). Следующие абонементы сдвигаются ближе."""
    if m.is_cancelled:
        return
    today = clock.today()
    later = queued_after(db, m)
    removed = (m.end_date - max(today, m.start_date)).days + 1 if m.end_date >= today else 0
    m.is_cancelled = True
    _shift(db, later, -removed)
    db.flush()
    drop_uncovered_bookings(db, m.user_id)
