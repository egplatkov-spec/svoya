from datetime import datetime
from enum import StrEnum

from sqlalchemy import Enum, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.db.types import UTCDateTime, utcnow


class OrderStatus(StrEnum):
    pending = "pending"
    paid = "paid"
    cancelled = "cancelled"
    refunded = "refunded"

    @property
    def label(self) -> str:
        return {"pending": "Ожидает оплаты", "paid": "Оплачен", "cancelled": "Отменён", "refunded": "Возврат"}[self.value]


class PaymentMethod(StrEnum):
    online = "online"  # ЮKassa
    fake = "fake"  # заглушка для разработки
    cash = "cash"  # наличные на ресепшене
    card = "card"  # терминал на ресепшене

    @property
    def label(self) -> str:
        return {"online": "Онлайн", "fake": "Тестовая", "cash": "Наличные", "card": "Карта (терминал)"}[self.value]


class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    amount_rub: Mapped[int]
    status: Mapped[OrderStatus] = mapped_column(Enum(OrderStatus, native_enum=False, length=16), default=OrderStatus.pending, index=True)
    method: Mapped[PaymentMethod] = mapped_column(Enum(PaymentMethod, native_enum=False, length=16))
    payment_id: Mapped[str | None] = mapped_column(String(64), unique=True, default=None)
    confirmation_url: Mapped[str | None] = mapped_column(String(500), default=None)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)
    paid_at: Mapped[datetime | None] = mapped_column(UTCDateTime, default=None)
    refunded_at: Mapped[datetime | None] = mapped_column(UTCDateTime, default=None)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), default=None)

    user: Mapped["User"] = relationship(foreign_keys=[user_id])  # noqa: F821
    product: Mapped["Product"] = relationship()  # noqa: F821
    created_by: Mapped["User | None"] = relationship(foreign_keys=[created_by_id])  # noqa: F821
