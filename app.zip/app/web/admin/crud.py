"""Мини-фреймворк для однотипных разделов админки (список → форма → сохранение → удаление).

Описываете поля и колонки — получаете четыре маршрута с валидацией и единым шаблоном.
"""
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, time
from enum import Enum
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.errors import DomainError
from app.core.flash import flash
from app.db.session import get_db
from app.web.deps import redirect
from app.web.templating import render

Choices = list[tuple[str, str]] | Callable[[Session], list[tuple[str, str]]]


@dataclass
class Field:
    name: str
    label: str
    kind: str = "text"  # text | textarea | markdown | int | bool | select | multicheck | time
    required: bool = True
    choices: Choices | None = None
    coerce: Callable[[str], Any] = str
    help: str = ""
    min: int | None = None
    max: int | None = None
    max_length: int = 200
    default: Any = None  # значение для пустого необязательного поля

    def options(self, db: Session) -> list[tuple[str, str]]:
        return self.choices(db) if callable(self.choices) else (self.choices or [])

    def display(self, value: Any) -> Any:
        if value is None:
            return ""
        if isinstance(value, Enum):
            return value.value
        if isinstance(value, time):
            return value.strftime("%H:%M")
        if self.kind == "multicheck":
            return [v for v in str(value).split(",") if v]
        return value

    def parse(self, db: Session, form) -> Any:
        raw = form.get(self.name)
        if self.kind == "bool":
            return self.name in form
        if self.kind == "multicheck":
            allowed = {k for k, _ in self.options(db)}
            return ",".join(v for v in form.getlist(self.name) if v in allowed)
        raw = (raw or "").strip()
        if not raw:
            if self.required:
                raise DomainError(f"Заполните поле «{self.label}»")
            return self.default if self.kind in ("int", "select", "time") else ""
        if self.kind == "int":
            try:
                value = int(raw)
            except ValueError as e:
                raise DomainError(f"«{self.label}»: нужно целое число") from e
            if self.min is not None and value < self.min:
                raise DomainError(f"«{self.label}»: не меньше {self.min}")
            if self.max is not None and value > self.max:
                raise DomainError(f"«{self.label}»: не больше {self.max}")
            return value
        if self.kind == "time":
            try:
                return datetime.strptime(raw, "%H:%M").time()
            except ValueError as e:
                raise DomainError(f"«{self.label}»: время в формате ЧЧ:ММ") from e
        if self.kind == "select":
            if raw not in {k for k, _ in self.options(db)}:
                raise DomainError(f"«{self.label}»: выберите вариант из списка")
            return self.coerce(raw)
        if self.kind == "text" and len(raw) > self.max_length:
            raise DomainError(f"«{self.label}»: не длиннее {self.max_length} символов")
        return raw


@dataclass
class Column:
    label: str
    get: Callable[[Any], Any]


@dataclass
class Crud:
    slug: str
    title: str
    singular: str
    model: type
    fields: list[Field]
    columns: list[Column]
    order_by: Callable[[], list] = field(default_factory=lambda: (lambda: []))
    validate: Callable[[Session, Any], None] | None = None
    intro: str = ""

    def register(self, router: APIRouter) -> None:
        base = f"/{self.slug}"

        @router.get(base, name=f"{self.slug}_list")
        def list_view(request: Request, db: Session = Depends(get_db)):
            rows = db.scalars(select(self.model).order_by(*self.order_by())).unique().all()
            return render(request, "admin/crud_list.html", crud=self, rows=rows, section=self.slug)

        @router.get(base + "/new", name=f"{self.slug}_new")
        def new_view(request: Request, db: Session = Depends(get_db)):
            return self._form(request, db, None, {})

        @router.post(base + "/new")
        async def create(request: Request, db: Session = Depends(get_db)):
            return await self._save(request, db, self.model())

        @router.get(base + "/{obj_id}", name=f"{self.slug}_edit")
        def edit_view(request: Request, obj_id: int, db: Session = Depends(get_db)):
            obj = self._get(db, obj_id)
            return self._form(request, db, obj, {f.name: f.display(getattr(obj, f.name)) for f in self.fields})

        @router.post(base + "/{obj_id}")
        async def update(request: Request, obj_id: int, db: Session = Depends(get_db)):
            return await self._save(request, db, self._get(db, obj_id))

        @router.post(base + "/{obj_id}/delete")
        def delete(request: Request, obj_id: int, db: Session = Depends(get_db)):
            db.delete(self._get(db, obj_id))
            try:
                db.commit()
            except IntegrityError:
                db.rollback()
                flash(request, "Нельзя удалить: запись уже используется. Снимите галочку «Активно», чтобы скрыть её.", "error")
                return redirect(f"/admin{base}/{obj_id}")
            flash(request, f"{self.singular} удалено")
            return redirect(f"/admin{base}")

    def _get(self, db: Session, obj_id: int):
        obj = db.get(self.model, obj_id)
        if obj is None:
            raise HTTPException(404, "Запись не найдена")
        return obj

    def _form(self, request: Request, db: Session, obj, values: dict, error: str | None = None, status: int = 200):
        options = {f.name: f.options(db) for f in self.fields if f.choices is not None}
        return render(request, "admin/crud_form.html", status_code=status, crud=self, obj=obj, values=values,
                      options=options, error=error, section=self.slug)

    async def _save(self, request: Request, db: Session, obj):
        form = await request.form()
        values = {f.name: (form.getlist(f.name) if f.kind == "multicheck" else form.get(f.name, "")) for f in self.fields}
        for f in self.fields:
            if f.kind == "bool":
                values[f.name] = f.name in form
        is_new = obj.id is None if hasattr(obj, "id") else True
        try:
            for f in self.fields:
                setattr(obj, f.name, f.parse(db, form))
            if self.validate:
                self.validate(db, obj)
            if is_new:
                db.add(obj)
            db.commit()
        except DomainError as e:
            db.rollback()
            return self._form(request, db, None if is_new else obj, values, e.message, 400)
        except IntegrityError:
            db.rollback()
            return self._form(request, db, None if is_new else obj, values, "Такая запись уже существует", 400)
        flash(request, "Сохранено")
        return redirect(f"/admin/{self.slug}")
