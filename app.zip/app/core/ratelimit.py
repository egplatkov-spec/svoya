"""Простой ограничитель частоты запросов в памяти процесса (защита входа и форм от перебора и спама).

Для нескольких экземпляров приложения замените хранилище на Redis.
"""
import time
from collections import defaultdict, deque
from threading import Lock

from fastapi import HTTPException, Request

from app.core.config import get_settings


class RateLimiter:
    def __init__(self, limit: int, window_seconds: int):
        self.limit = limit
        self.window = window_seconds
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()

    def check(self, key: str) -> bool:
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > self.window:
                q.popleft()
            if len(q) >= self.limit:
                return False
            q.append(now)
            return True

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


def client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def enforce(limiter: RateLimiter, request: Request, scope: str) -> None:
    if not get_settings().rate_limit_enabled:
        return
    if not limiter.check(f"{scope}:{client_ip(request)}"):
        raise HTTPException(429, "Слишком много попыток. Подождите несколько минут.")


login_limiter = RateLimiter(limit=10, window_seconds=300)
form_limiter = RateLimiter(limit=5, window_seconds=600)
