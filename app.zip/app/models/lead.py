from datetime import datetime
from enum import StrEnum

from sqlalchemy import Enum, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base
from app.db.types import UTCDateTime, utcnow


class LeadStatus(StrEnum):
    new = "new"
    contacted = "contacted"
    trial = "trial"
    converted = "converted"
    rejected = "rejected"

    @property
    def label(self) -> str:
        return {
            "new": "Новая", "contacted": "Связались", "trial": "Записана на пробное",
            "converted": "Купила абонемент", "rejected": "Отказ",
        }[self.value]


class Lead(Base):
    """Заявка с формы предзаписи на пробное занятие."""

    __tablename__ = "leads"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    phone: Mapped[str] = mapped_column(String(16), index=True)
    district: Mapped[str] = mapped_column(String(50), default="")
    interests: Mapped[str] = mapped_column(String(200), default="")  # через запятую
    times: Mapped[str] = mapped_column(String(100), default="")  # через запятую
    status: Mapped[LeadStatus] = mapped_column(Enum(LeadStatus, native_enum=False, length=16), default=LeadStatus.new, index=True)
    comment: Mapped[str] = mapped_column(Text, default="")
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), default=None)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)
