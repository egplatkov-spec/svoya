"""Публичная часть: лендинг, предзапись, расписание с записью, текстовые страницы, покупка."""
import logging
from collections import defaultdict
from datetime import date

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.content import DISTRICTS, INTERESTS, ROADMAP, TIMES
from app.core import clock
from app.core.config import get_settings
from app.core.csrf import verify_csrf
from app.core.errors import DomainError
from app.core.flash import flash
from app.core.ratelimit import enforce, form_limiter
from app.db.session import get_db
from app.models import FaqItem, Page, Product, User
from app.services import bookings, leads, orders
from app.services.payments import PaymentError, PaymentProvider, get_payment_provider
from app.web.deps import load_user, redirect, require_user, safe_next
from app.web.templating import render

log = logging.getLogger(__name__)
router = APIRouter(dependencies=[Depends(load_user), Depends(verify_csrf)])


def active_products(db: Session) -> list[Product]:
    return list(db.scalars(select(Product).where(Product.is_active.is_(True)).order_by(Product.sort, Product.price_rub)))


def weekly_grid(db: Session) -> tuple[list[int], list[str], dict]:
    """Таблица «время × день недели» для лендинга."""
    slots = [s for s in bookings.active_slots(db) if s.class_type.is_active]
    days = sorted({s.weekday for s in slots} | set(range(6)))
    times = sorted({s.start_time for s in slots})
    grid: dict = defaultdict(dict)
    for s in slots:
        grid[s.start_time][s.weekday] = s
    return days, times, grid


@router.get("/")
def landing(request: Request, db: Session = Depends(get_db)):
    days, times, grid = weekly_grid(db)
    faq = db.scalars(select(FaqItem).where(FaqItem.is_published.is_(True)).order_by(FaqItem.sort)).all()
    draft = request.session.pop("lead_draft", {})
    return render(
        request, "public/landing.html",
        products=active_products(db), days=days, times=times, grid=grid, faq=faq,
        districts=DISTRICTS, interests=INTERESTS, time_options=TIMES, roadmap=ROADMAP, draft=draft,
    )


@router.post("/lead")
def lead_submit(
    request: Request,
    name: str = Form(""),
    phone: str = Form(""),
    district: str = Form(""),
    interests: list[str] = Form([]),
    times: list[str] = Form([]),
    consent: bool = Form(False),
    website: str = Form(""),  # скрытое поле-ловушка для ботов
    db: Session = Depends(get_db),
):
    if website:
        return redirect("/thanks")
    enforce(form_limiter, request, "lead")
    try:
        leads.create_lead(db, name=name, phone=phone, district=district, interests=interests, times=times, consent=consent)
    except DomainError as e:
        request.session["lead_draft"] = {"name": name[:100], "phone": phone[:30], "district": district,
                                         "interests": interests, "times": times}
        flash(request, e.message, "error")
        return redirect("/#signup")
    return redirect("/thanks")


@router.get("/thanks")
def thanks(request: Request):
    return render(request, "public/thanks.html")


@router.get("/schedule")
def schedule(request: Request, day: date | None = None, db: Session = Depends(get_db)):
    s = get_settings()
    today = clock.today()
    days_map = bookings.occurrences(db, today, s.booking_days_ahead, getattr(request.state, "user", None))
    selected = day if day in days_map else today
    return render(request, "public/schedule.html", days_map=days_map, selected=selected, occurrences=days_map[selected])


@router.post("/schedule/book")
def book(
    request: Request,
    slot_id: int = Form(...),
    class_date: date = Form(...),
    user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    b = bookings.book(db, user, slot_id, class_date)
    flash(request, f"Вы записаны: {b.slot.class_type.name}, {class_date.strftime('%d.%m')} в {b.slot.start_time:%H:%M}")
    return redirect(f"/schedule?day={class_date.isoformat()}")


@router.post("/bookings/{booking_id}/cancel")
def cancel_booking(request: Request, booking_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    b = bookings.cancel(db, user, booking_id)
    flash(request, "Запись отменена")
    return redirect(safe_next(request.query_params.get("next"), f"/schedule?day={b.class_date.isoformat()}"))


@router.post("/buy/{product_id}")
def buy(
    request: Request,
    product_id: int,
    db: Session = Depends(get_db),
    provider: PaymentProvider = Depends(get_payment_provider),
):
    user = getattr(request.state, "user", None)
    if user is None:
        flash(request, "Войдите или зарегистрируйтесь, чтобы купить абонемент", "info")
        return redirect("/register?next=/%23prices")
    try:
        order, confirmation_url = orders.start_purchase(db, user, db.get(Product, product_id), provider)
    except PaymentError:
        log.exception("Не удалось создать платёж")
        flash(request, "Платёжная система временно недоступна. Попробуйте через несколько минут.", "error")
        return redirect("/#prices")
    if confirmation_url:
        return redirect(confirmation_url)
    flash(request, f"Оплата прошла. «{order.product.name}» уже в вашем кабинете!")
    return redirect("/account")


@router.get("/p/{slug}")
def page(request: Request, slug: str, db: Session = Depends(get_db)):
    p = db.scalar(select(Page).where(Page.slug == slug, Page.is_published.is_(True)))
    if p is None:
        raise HTTPException(404, "Страница не найдена")
    return render(request, "public/page.html", page=p)


@router.get("/robots.txt")
def robots(request: Request):
    from fastapi.responses import PlainTextResponse

    site = get_settings().site_url.rstrip("/")
    return PlainTextResponse(f"User-agent: *\nDisallow: /admin\nDisallow: /account\nSitemap: {site}/sitemap.xml\n")


@router.get("/sitemap.xml")
def sitemap(db: Session = Depends(get_db)):
    from fastapi.responses import Response

    site = get_settings().site_url.rstrip("/")
    urls = ["/", "/schedule"] + [f"/p/{s}" for s in db.scalars(select(Page.slug).where(Page.is_published.is_(True)))]
    body = "".join(f"<url><loc>{site}{u}</loc></url>" for u in urls)
    xml = f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{body}</urlset>'
    return Response(xml, media_type="application/xml")
