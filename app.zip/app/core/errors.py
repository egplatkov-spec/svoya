class DomainError(Exception):
    """Ошибка бизнес-правила; текст показывается пользователю как есть."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message
