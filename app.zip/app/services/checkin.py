"""Отметка прихода по QR-пропуску на ресепшене."""
from dataclasses import dataclass
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core import clock
from app.core.errors import DomainError
from app.models import Membership, MembershipState, User, Visit
from app.services import bookings, memberships, personal


@dataclass
class PassCheck:
    user: User
    membership: Membership | None
    state: MembershipState | None
    personal_left: int
    last_visit: Visit | None
    today_bookings: list

    @property
    def can_enter(self) -> bool:
        return self.state == MembershipState.active or self.personal_left > 0

    @property
    def visited_today(self) -> bool:
        return self.last_visit is not None and clock.local(self.last_visit.created_at).date() == clock.today()


def find_by_code(db: Session, code: str) -> User | None:
    return db.scalar(select(User).where(User.pass_code == code))


def check(db: Session, user: User) -> PassCheck:
    today = clock.today()
    m = memberships.membership_on(db, user.id, today)
    last = db.scalar(select(Visit).where(Visit.user_id == user.id).order_by(Visit.created_at.desc()).limit(1))
    todays = [b for b in bookings.upcoming_for_user(db, user.id) if b.class_date == today]
    return PassCheck(
        user=user, membership=m, state=m.state_on(today) if m else None,
        personal_left=personal.sessions_left(db, user.id), last_visit=last, today_bookings=todays,
    )


def register_visit(db: Session, user: User, admin: User) -> Visit:
    if not user.is_active:
        raise DomainError("Аккаунт заблокирован")
    result = check(db, user)
    if not result.can_enter:
        raise DomainError("Нет действующего абонемента или персональных тренировок")
    visit = Visit(user_id=user.id, membership_id=result.membership.id if result.membership else None, admin_id=admin.id)
    db.add(visit)
    db.commit()
    return visit


def visits_between(db: Session, start: datetime, end: datetime) -> list[Visit]:
    return list(db.scalars(
        select(Visit).where(Visit.created_at >= start, Visit.created_at < end).order_by(Visit.created_at.desc())
    ))
