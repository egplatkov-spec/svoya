import segno

from app.core.config import get_settings


def pass_url(pass_code: str) -> str:
    return f"{get_settings().site_url.rstrip('/')}/admin/checkin/{pass_code}"


def pass_qr_svg(pass_code: str) -> str:
    """SVG QR-кода пропуска. Администратор сканирует его камерой телефона и попадает на экран отметки."""
    return segno.make(pass_url(pass_code), error="m").svg_inline(scale=6, border=2, dark="#0f2a2a", light="#ffffff")
