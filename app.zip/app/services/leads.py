from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.content import DISTRICTS, INTERESTS, TIMES
from app.core.errors import DomainError
from app.core.phone import format_phone
from app.db.types import utcnow
from app.models import Lead, LeadStatus
from app.services.notify import notify_admin
from app.services.users import clean_name, clean_phone


def create_lead(
    db: Session, *, name: str, phone: str, district: str, interests: list[str], times: list[str], consent: bool
) -> Lead:
    if not consent:
        raise DomainError("Нужно согласие на обработку персональных данных")
    name, phone = clean_name(name), clean_phone(phone)
    if district not in DISTRICTS:
        raise DomainError("Выберите район из списка")
    interests = [i for i in interests if i in INTERESTS]
    times = [t for t in times if t in TIMES]

    # Повторная отправка той же формы в течение 10 минут обновляет заявку, а не плодит дубли
    recent = db.scalar(
        select(Lead).where(Lead.phone == phone, Lead.created_at >= utcnow() - timedelta(minutes=10))
    )
    lead = recent or Lead(phone=phone)
    lead.name, lead.district = name, district
    lead.interests, lead.times = ",".join(interests), ",".join(times)
    if recent is None:
        db.add(lead)
    db.commit()

    if recent is None:
        labels = ", ".join(INTERESTS[i] for i in interests) or "—"
        when = ", ".join(TIMES[t] for t in times) or "—"
        notify_admin(f"🆕 Заявка на пробное\n{name}, {format_phone(phone)}\nРайон: {district}\nИнтересно: {labels}\nВремя: {when}")
    return lead


def update_lead(db: Session, lead: Lead, *, status: str, comment: str) -> Lead:
    try:
        lead.status = LeadStatus(status)
    except ValueError as e:
        raise DomainError("Неизвестный статус") from e
    lead.comment = (comment or "")[:2000]
    db.commit()
    return lead


def district_votes(db: Session) -> list[tuple[str, int]]:
    rows = db.execute(
        select(Lead.district, func.count()).where(Lead.district != "").group_by(Lead.district).order_by(func.count().desc())
    ).all()
    return [(d, c) for d, c in rows]
