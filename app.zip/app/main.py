import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException
from starlette.middleware.sessions import SessionMiddleware

from app import models  # noqa: F401  — регистрирует модели
from app.core.config import get_settings
from app.core.errors import DomainError
from app.core.flash import flash
from app.db.seed import ensure_admin
from app.db.session import SessionLocal
from app.web import account, api, auth, payments, public
from app.web.admin import router as admin_router
from app.web.deps import LoginRequired, back, redirect
from app.web.templating import render

settings = get_settings()
logging.basicConfig(level=logging.DEBUG if settings.debug else logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("app")
BASE_DIR = Path(__file__).resolve().parent

if not settings.debug and settings.secret_key == "dev-secret-change-me":
    raise RuntimeError("Задайте SECRET_KEY в .env перед запуском в боевом режиме")


@asynccontextmanager
async def lifespan(app: FastAPI):
    with SessionLocal() as db:
        ensure_admin(db)
    yield


app = FastAPI(
    title=f"Клуб «{settings.club_name}»", debug=False, lifespan=lifespan,
    docs_url="/docs", redoc_url=None, openapi_url="/openapi.json",
)
app.add_middleware(
    SessionMiddleware, secret_key=settings.secret_key, session_cookie="svoya_session",
    max_age=60 * 60 * 24 * 30, same_site="lax", https_only=not settings.debug,
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    h = response.headers
    h.setdefault("X-Content-Type-Options", "nosniff")
    h.setdefault("X-Frame-Options", "DENY")
    h.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if not request.url.path.startswith("/docs"):
        h.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src https://fonts.gstatic.com; script-src 'self'; frame-ancestors 'none'; base-uri 'self'",
        )
    if not settings.debug:
        h.setdefault("Strict-Transport-Security", "max-age=31536000")
    return response


app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
for r in (public.router, auth.router, account.router, payments.router, api.router, admin_router):
    app.include_router(r)


# --- Обработка ошибок: красивые страницы для людей, JSON для API ---

def _wants_json(request: Request) -> bool:
    return request.url.path.startswith(("/api/", "/payments/yookassa"))


@app.exception_handler(LoginRequired)
async def login_required_handler(request: Request, exc: LoginRequired):
    if _wants_json(request):
        return JSONResponse({"detail": "Unauthorized"}, status_code=401)
    return redirect(f"/login?next={exc.next_url}")


@app.exception_handler(DomainError)
async def domain_error_handler(request: Request, exc: DomainError):
    if _wants_json(request):
        return JSONResponse({"detail": exc.message}, status_code=400)
    flash(request, exc.message, "error")
    return back(request)


@app.exception_handler(HTTPException)
async def http_error_handler(request: Request, exc: HTTPException):
    if _wants_json(request):
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=exc.headers)
    titles = {403: "Нет доступа", 404: "Страница не найдена", 429: "Слишком много запросов"}
    return render(request, "errors/error.html", status_code=exc.status_code,
                  code=exc.status_code, title=titles.get(exc.status_code, "Ошибка"), message=exc.detail)


@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    if _wants_json(request):
        return JSONResponse({"detail": exc.errors()}, status_code=422)
    flash(request, "Проверьте, что все поля формы заполнены правильно", "error")
    return back(request)


@app.exception_handler(Exception)
async def unhandled_error_handler(request: Request, exc: Exception):
    log.exception("Необработанная ошибка на %s", request.url.path)
    if _wants_json(request):
        return JSONResponse({"detail": "Internal error"}, status_code=500)
    return render(request, "errors/error.html", status_code=500, code=500, title="Что-то пошло не так",
                  message="Мы уже знаем об ошибке. Попробуйте обновить страницу через минуту.")
