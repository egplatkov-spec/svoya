from fastapi import APIRouter, Depends, Form, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.content import INTERESTS, TIMES
from app.core.flash import flash
from app.db.session import get_db
from app.models import Lead, LeadStatus
from app.services import leads
from app.web.deps import redirect
from app.web.templating import render

router = APIRouter(prefix="/leads")
PAGE = 50


@router.get("")
def lead_list(request: Request, status: str = "", page: int = 1, db: Session = Depends(get_db)):
    q = select(Lead).order_by(Lead.created_at.desc())
    if status in LeadStatus.__members__:
        q = q.where(Lead.status == LeadStatus(status))
    page = max(1, page)
    rows = db.scalars(q.limit(PAGE + 1).offset((page - 1) * PAGE)).all()
    counts = dict(db.execute(select(Lead.status, func.count()).group_by(Lead.status)).all())
    return render(request, "admin/leads.html", section="leads", leads=rows[:PAGE], has_next=len(rows) > PAGE,
                  page=page, status=status, statuses=list(LeadStatus), counts=counts,
                  interests=INTERESTS, time_options=TIMES)


@router.get("/{lead_id}")
def lead_edit(request: Request, lead_id: int, db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id) or _404()
    return render(request, "admin/lead.html", section="leads", lead=lead, statuses=list(LeadStatus),
                  interests=INTERESTS, time_options=TIMES)


@router.post("/{lead_id}")
def lead_save(request: Request, lead_id: int, status: str = Form(...), comment: str = Form(""), db: Session = Depends(get_db)):
    lead = db.get(Lead, lead_id) or _404()
    leads.update_lead(db, lead, status=status, comment=comment)
    flash(request, "Заявка обновлена")
    return redirect("/admin/leads")


def _404():
    raise HTTPException(404, "Заявка не найдена")
