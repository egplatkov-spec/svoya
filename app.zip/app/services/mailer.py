"""Отправка писем через SMTP. Если SMTP не настроен — письмо пишется в лог (удобно при разработке)."""
import logging
import smtplib
import ssl
import threading
from email.message import EmailMessage

from app.core.config import get_settings

log = logging.getLogger(__name__)


def _deliver(msg: EmailMessage) -> None:
    s = get_settings()
    try:
        if s.smtp_ssl:
            with smtplib.SMTP_SSL(s.smtp_host, s.smtp_port, context=ssl.create_default_context(), timeout=20) as smtp:
                smtp.login(s.smtp_user, s.smtp_password)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=20) as smtp:
                smtp.starttls(context=ssl.create_default_context())
                smtp.login(s.smtp_user, s.smtp_password)
                smtp.send_message(msg)
    except (smtplib.SMTPException, OSError):
        log.exception("Не удалось отправить письмо на %s", msg["To"])


def send_email(to: str, subject: str, body: str) -> None:
    s = get_settings()
    if not s.smtp_host:
        log.warning("SMTP не настроен. Письмо для %s:\n%s\n%s", to, subject, body)
        return
    msg = EmailMessage()
    msg["From"] = s.smtp_from or s.smtp_user
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    threading.Thread(target=_deliver, args=(msg,), daemon=True).start()
