from datetime import date, datetime
from enum import StrEnum

from sqlalchemy import Date, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.db.types import UTCDateTime, utcnow


class MembershipState(StrEnum):
    upcoming = "upcoming"
    active = "active"
    frozen = "frozen"
    expired = "expired"
    cancelled = "cancelled"

    @property
    def label(self) -> str:
        return {
            "upcoming": "Ещё не начался", "active": "Действует", "frozen": "Заморожен",
            "expired": "Закончился", "cancelled": "Аннулирован",
        }[self.value]


class Membership(Base):
    """Абонемент на период start_date..end_date (включительно). Заморозка сдвигает end_date."""

    __tablename__ = "memberships"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), unique=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    freeze_days_allowed: Mapped[int] = mapped_column(default=0)
    is_cancelled: Mapped[bool] = mapped_column(default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)

    product: Mapped["Product"] = relationship()  # noqa: F821
    order: Mapped["Order"] = relationship()  # noqa: F821
    freezes: Mapped[list["Freeze"]] = relationship(
        back_populates="membership", order_by="Freeze.start_date", cascade="all, delete-orphan"
    )

    @property
    def freeze_days_used(self) -> int:
        return sum(f.days for f in self.freezes)

    @property
    def freeze_days_left(self) -> int:
        return max(0, self.freeze_days_allowed - self.freeze_days_used)

    def freeze_on(self, d: date) -> "Freeze | None":
        return next((f for f in self.freezes if f.start_date <= d <= f.end_date), None)

    def state_on(self, d: date) -> MembershipState:
        if self.is_cancelled:
            return MembershipState.cancelled
        if d < self.start_date:
            return MembershipState.upcoming
        if d > self.end_date:
            return MembershipState.expired
        if self.freeze_on(d):
            return MembershipState.frozen
        return MembershipState.active

    def days_left(self, d: date) -> int:
        return max(0, (self.end_date - max(d, self.start_date)).days + 1)


class Freeze(Base):
    __tablename__ = "freezes"

    id: Mapped[int] = mapped_column(primary_key=True)
    membership_id: Mapped[int] = mapped_column(ForeignKey("memberships.id", ondelete="CASCADE"), index=True)
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)

    membership: Mapped[Membership] = relationship(back_populates="freezes")

    @property
    def days(self) -> int:
        return (self.end_date - self.start_date).days + 1
