"""Заказы: онлайн-покупка, продажа на ресепшене, выдача купленного, возврат."""
import logging
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.errors import DomainError
from app.core.phone import format_phone
from app.db.types import utcnow
from app.models import (
    Membership,
    Order,
    OrderStatus,
    PaymentMethod,
    PersonalPackage,
    Product,
    ProductKind,
    User,
)
from app.services import memberships, personal
from app.services.notify import notify_admin
from app.services.payments import CANCELED, SUCCEEDED, PaymentError, PaymentProvider

log = logging.getLogger(__name__)


def _return_url(order: Order) -> str:
    return f"{get_settings().site_url.rstrip('/')}/payments/return?order_id={order.id}"


def fulfill(db: Session, order: Order) -> None:
    """Выдаёт купленное: абонемент или пакет персональных тренировок (идемпотентно)."""
    if order.product.kind == ProductKind.membership:
        memberships.create_membership(db, order)
    else:
        personal.create_package(db, order)


def mark_paid(db: Session, order: Order) -> Order:
    if order.status == OrderStatus.paid:
        return order
    if order.status == OrderStatus.refunded:
        raise DomainError("По заказу уже сделан возврат")
    order.status = OrderStatus.paid
    order.paid_at = utcnow()
    fulfill(db, order)
    db.commit()
    notify_admin(
        f"💳 Оплата {order.amount_rub} ₽ ({order.method.label})\n{order.product.name}\n"
        f"{order.user.name}, {format_phone(order.user.phone)}"
    )
    return order


def apply_payment_status(db: Session, order: Order, status: str) -> Order:
    if status == SUCCEEDED:
        return mark_paid(db, order)
    if status == CANCELED and order.status == OrderStatus.pending:
        order.status = OrderStatus.cancelled
        db.commit()
    return order


def _ensure_can_buy(product: Product | None) -> Product:
    if product is None or not product.is_active:
        raise DomainError("Этот тариф сейчас недоступен")
    if product.price_rub <= 0:
        raise DomainError("Этот тариф нельзя купить онлайн")
    return product


def start_purchase(db: Session, user: User, product: Product | None, provider: PaymentProvider) -> tuple[Order, str | None]:
    """Создаёт заказ и платёж. Возвращает заказ и ссылку на оплату (None — если уже оплачено)."""
    product = _ensure_can_buy(product)
    order = Order(user_id=user.id, product_id=product.id, amount_rub=product.price_rub, method=provider.method)
    db.add(order)
    db.commit()
    try:
        result = provider.create_payment(order, _return_url(order))
    except PaymentError:
        order.status = OrderStatus.cancelled
        db.commit()
        raise
    order.payment_id = result.payment_id
    order.confirmation_url = result.confirmation_url
    db.commit()
    apply_payment_status(db, order, result.status)
    return order, (None if order.status == OrderStatus.paid else result.confirmation_url)


def sync_order(db: Session, order: Order, provider: PaymentProvider) -> Order:
    """Запрашивает статус платежа у провайдера; брошенные заказы старше TTL отменяет."""
    if order.status != OrderStatus.pending or order.method not in (PaymentMethod.online, PaymentMethod.fake):
        return order
    if order.payment_id:
        apply_payment_status(db, order, provider.get_status(order.payment_id))
    if order.status == OrderStatus.pending and utcnow() - order.created_at > timedelta(hours=24):
        order.status = OrderStatus.cancelled  # ЮKassa сама отменяет неоплаченные платежи, это страховка
        db.commit()
    return order


def sync_pending_for_user(db: Session, user_id: int, provider: PaymentProvider) -> None:
    pending = db.scalars(
        select(Order).where(Order.user_id == user_id, Order.status == OrderStatus.pending).limit(5)
    ).all()
    for order in pending:
        try:
            sync_order(db, order, provider)
        except PaymentError:
            log.warning("Не удалось проверить платёж заказа %s", order.id)


def resume_payment(db: Session, user: User, order: Order, provider: PaymentProvider) -> str | None:
    """«Оплатить» неоплаченный заказ: свежая ссылка ЮKassa или новый платёж."""
    if order.user_id != user.id:
        raise DomainError("Заказ не найден")
    sync_order(db, order, provider)
    if order.status == OrderStatus.paid:
        return None
    ttl = timedelta(minutes=get_settings().pending_order_ttl_minutes)
    if order.status == OrderStatus.pending and order.confirmation_url and utcnow() - order.created_at < ttl:
        return order.confirmation_url
    if order.status == OrderStatus.pending:
        order.status = OrderStatus.cancelled
        db.commit()
    _, url = start_purchase(db, user, order.product, provider)
    return url


def manual_sale(db: Session, admin: User, user: User, product: Product | None, method: PaymentMethod) -> Order:
    """Продажа на ресепшене за наличные или по терминалу — сразу оплачено."""
    if method not in (PaymentMethod.cash, PaymentMethod.card):
        raise DomainError("Выберите способ оплаты")
    product = _ensure_can_buy(product)
    order = Order(
        user_id=user.id, product_id=product.id, amount_rub=product.price_rub, method=method, created_by_id=admin.id,
    )
    db.add(order)
    db.flush()
    return mark_paid(db, order)


def refund(db: Session, order: Order, provider: PaymentProvider) -> Order:
    """Возврат: деньги через ЮKassa (для онлайн-оплаты), абонемент/пакет аннулируется."""
    if order.status != OrderStatus.paid:
        raise DomainError("Вернуть можно только оплаченный заказ")
    if order.method == PaymentMethod.online:
        provider.refund(order)
    m = db.scalar(select(Membership).where(Membership.order_id == order.id))
    if m:
        memberships.cancel_membership(db, m)
    pkg = db.scalar(select(PersonalPackage).where(PersonalPackage.order_id == order.id))
    if pkg:
        pkg.is_cancelled = True
    order.status = OrderStatus.refunded
    order.refunded_at = utcnow()
    db.commit()
    return order
