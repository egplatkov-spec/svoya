from functools import lru_cache
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Все настройки берутся из переменных окружения / файла .env."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Приложение ---
    debug: bool = True
    secret_key: str = "dev-secret-change-me"
    database_url: str = "sqlite:///./app.db"
    site_url: str = "http://127.0.0.1:8000"  # публичный адрес: ссылки в письмах, QR, возврат из ЮKassa
    timezone: str = "Europe/Moscow"
    rate_limit_enabled: bool = True
    # Демо-показ: при старте создаются демо-аккаунты, а на странице входа видны их логины и пароли
    demo_mode: bool = False

    # --- Клуб ---
    club_name: str = "Своя"
    club_tagline: str = "Женский фитнес-клуб"
    club_district: str = "Марьино"
    club_address: str = "Москва, Марьино — точный адрес сообщим при записи"
    club_phone: str = "+7 (900) 000-00-00"
    club_email: str = "hello@svoya.club"
    club_hours: str = "Ежедневно 7:00–23:00"
    legal_entity: str = "ИП Фамилия Имя Отчество, ИНН 000000000000"

    # --- Правила ---
    booking_days_ahead: int = 14  # на сколько дней вперёд открыта запись
    booking_cancel_minutes: int = 60  # отменить запись можно не позже чем за N минут до начала
    pending_order_ttl_minutes: int = 60  # через сколько неоплаченный заказ считается брошенным

    # --- Администратор, создаётся при старте, если ещё нет ни одного ---
    admin_phone: str = ""
    admin_password: str = ""
    admin_name: str = "Администратор"

    # --- Оплата ---
    payment_provider: Literal["fake", "yookassa"] = "fake"
    yookassa_shop_id: str = ""
    yookassa_secret_key: str = ""
    yookassa_send_receipt: bool = False
    yookassa_vat_code: int = 1

    # --- Почта (сброс пароля). Без SMTP письма пишутся в лог ---
    smtp_host: str = ""
    smtp_port: int = 465
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_ssl: bool = True

    # --- Уведомления администратору в Telegram (новые заявки и оплаты) ---
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")


@lru_cache
def get_settings() -> Settings:
    return Settings()
