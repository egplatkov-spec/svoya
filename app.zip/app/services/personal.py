from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import DomainError
from app.models import Order, PersonalPackage, PersonalSessionUse, ProductKind, User


def create_package(db: Session, order: Order) -> PersonalPackage:
    existing = db.scalar(select(PersonalPackage).where(PersonalPackage.order_id == order.id))
    if existing:
        return existing
    product = order.product
    if product.kind != ProductKind.personal or not product.sessions:
        raise DomainError("Этот товар не является персональными тренировками")
    pkg = PersonalPackage(user_id=order.user_id, order_id=order.id, product_id=product.id, sessions_total=product.sessions)
    db.add(pkg)
    db.flush()
    return pkg


def packages_for_user(db: Session, user_id: int) -> list[PersonalPackage]:
    return list(db.scalars(
        select(PersonalPackage).where(PersonalPackage.user_id == user_id).order_by(PersonalPackage.created_at.desc())
    ))


def sessions_left(db: Session, user_id: int) -> int:
    return sum(p.remaining for p in packages_for_user(db, user_id))


def use_session(db: Session, pkg: PersonalPackage, admin: User, note: str = "") -> PersonalSessionUse:
    if pkg.remaining <= 0:
        raise DomainError("В пакете не осталось тренировок")
    pkg.sessions_used += 1
    use = PersonalSessionUse(admin_id=admin.id, note=(note or "")[:200])
    pkg.uses.append(use)
    db.commit()
    return use
