"""Открытое JSON API только для чтения (для мобильного приложения, виджетов, интеграций). Документация: /docs"""
from datetime import date, time

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core import clock
from app.db.session import get_db
from app.models import FaqItem, ProductKind
from app.services import bookings
from app.web.public import active_products

router = APIRouter(prefix="/api", tags=["api"])


class ProductOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    kind: ProductKind
    name: str
    description: str
    price_rub: int
    duration_days: int | None
    freeze_days: int
    sessions: int | None
    badge: str


class ClassOut(BaseModel):
    slot_id: int
    date: date
    start: time
    duration_min: int
    name: str
    subtitle: str
    tags: list[str]
    trainer: str
    capacity: int
    free: int


class FaqOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    question: str
    answer: str


@router.get("/health")
def health():
    return {"status": "ok"}


@router.get("/products", response_model=list[ProductOut])
def products(db: Session = Depends(get_db)):
    return active_products(db)


@router.get("/schedule", response_model=list[ClassOut])
def schedule(days: int = Query(7, ge=1, le=14), db: Session = Depends(get_db)):
    out = []
    for d, occ in bookings.occurrences(db, clock.today(), days).items():
        for o in occ:
            ct = o.slot.class_type
            out.append(ClassOut(
                slot_id=o.slot.id, date=d, start=o.slot.start_time, duration_min=o.slot.duration_min, name=ct.name,
                subtitle=ct.subtitle, tags=ct.tag_list, trainer=o.slot.trainer, capacity=o.slot.capacity, free=o.free,
            ))
    return out


@router.get("/faq", response_model=list[FaqOut])
def faq(db: Session = Depends(get_db)):
    return db.scalars(select(FaqItem).where(FaqItem.is_published.is_(True)).order_by(FaqItem.sort)).all()
