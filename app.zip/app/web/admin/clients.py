"""Клиентки: поиск, карточка, продажа на ресепшене, заморозка, персональные, отметка визита."""
from datetime import date

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core import clock
from app.core.errors import DomainError
from app.core.flash import flash
from app.db.session import get_db
from app.models import (
    Booking,
    Freeze,
    Lead,
    LeadStatus,
    Membership,
    Order,
    PaymentMethod,
    PersonalPackage,
    Product,
    Role,
    User,
    Visit,
)
from app.services import checkin, memberships, orders, personal, users
from app.web.deps import redirect, require_admin
from app.web.templating import render

router = APIRouter(prefix="/clients")
PAGE = 50


def _client(db: Session, user_id: int) -> User:
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(404, "Клиентка не найдена")
    return user


@router.get("")
def client_list(request: Request, q: str = "", page: int = 1, db: Session = Depends(get_db)):
    page = max(1, page)
    rows = users.search(db, q, limit=PAGE + 1, offset=(page - 1) * PAGE)
    today = clock.today()
    active = {m.user_id: m for m in db.scalars(
        select(Membership).where(Membership.is_cancelled.is_(False), Membership.start_date <= today, Membership.end_date >= today)
    )}
    return render(request, "admin/clients.html", section="clients", clients=rows[:PAGE], has_next=len(rows) > PAGE,
                  page=page, q=q, active=active, today=today)


@router.get("/new")
def client_new(request: Request, lead: int | None = None, db: Session = Depends(get_db)):
    form = {"name": "", "phone": "", "email": ""}
    if lead and (ld := db.get(Lead, lead)):
        form.update(name=ld.name, phone=ld.phone)
    return render(request, "admin/client_new.html", section="clients", form=form, lead_id=lead)


@router.post("/new")
def client_create(
    request: Request,
    name: str = Form(""),
    phone: str = Form(""),
    email: str = Form(""),
    lead_id: int | None = Form(None),
    db: Session = Depends(get_db),
):
    try:
        user, password = users.create_by_admin(db, name=name, phone=phone, email=email)
    except DomainError as e:
        return render(request, "admin/client_new.html", section="clients", status_code=400,
                      form={"name": name, "phone": phone, "email": email}, lead_id=lead_id, error=e.message)
    if lead_id and (ld := db.get(Lead, lead_id)):
        ld.user_id = user.id
        if ld.status in (LeadStatus.new, LeadStatus.contacted):
            ld.status = LeadStatus.trial
        db.commit()
    request.session["temp_password"] = {"uid": user.id, "password": password}
    return redirect(f"/admin/clients/{user.id}")


@router.get("/{user_id}")
def client_card(request: Request, user_id: int, db: Session = Depends(get_db)):
    user = _client(db, user_id)
    today = clock.today()
    temp = request.session.pop("temp_password", None)
    return render(
        request, "admin/client.html", section="clients", client=user,
        temp_password=temp["password"] if temp and temp.get("uid") == user.id else None,
        memberships=memberships.user_memberships(db, user.id, include_cancelled=True),
        packages=personal.packages_for_user(db, user.id),
        orders=db.scalars(select(Order).where(Order.user_id == user.id).order_by(Order.created_at.desc())).all(),
        visits=db.scalars(select(Visit).where(Visit.user_id == user.id).order_by(Visit.created_at.desc()).limit(20)).all(),
        bookings=db.scalars(select(Booking).where(Booking.user_id == user.id).order_by(Booking.class_date.desc()).limit(20)).unique().all(),
        products=db.scalars(select(Product).where(Product.is_active.is_(True)).order_by(Product.sort)).all(),
        methods=[PaymentMethod.cash, PaymentMethod.card], pass_check=checkin.check(db, user), today_=today,
        leads=db.scalars(select(Lead).where(Lead.phone == user.phone).order_by(Lead.created_at.desc())).all(),
    )


@router.post("/{user_id}")
def client_save(
    request: Request,
    user_id: int,
    name: str = Form(""),
    phone: str = Form(""),
    email: str = Form(""),
    admin_note: str = Form(""),
    is_active: bool = Form(False),
    is_admin: bool = Form(False),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    user = _client(db, user_id)
    if user.id == admin.id and (not is_active or not is_admin):
        raise DomainError("Нельзя заблокировать себя или снять с себя права администратора")
    users.update_profile(db, user, name=name, phone=phone, email=email)
    user.admin_note = admin_note[:5000]
    user.is_active = is_active
    user.role = Role.admin if is_admin else Role.client
    db.commit()
    flash(request, "Данные сохранены")
    return redirect(f"/admin/clients/{user.id}")


@router.post("/{user_id}/sell")
def sell(
    request: Request,
    user_id: int,
    product_id: int = Form(...),
    method: PaymentMethod = Form(...),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    user = _client(db, user_id)
    order = orders.manual_sale(db, admin, user, db.get(Product, product_id), method)
    flash(request, f"Продано: {order.product.name} за {order.amount_rub} ₽ ({method.label})")
    return redirect(f"/admin/clients/{user.id}")


@router.post("/{user_id}/checkin")
def checkin_visit(request: Request, user_id: int, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = _client(db, user_id)
    checkin.register_visit(db, user, admin)
    flash(request, f"Визит отмечен: {user.name}")
    return redirect(f"/admin/clients/{user.id}")


@router.post("/{user_id}/reset-password")
def reset_password(request: Request, user_id: int, db: Session = Depends(get_db)):
    user = _client(db, user_id)
    request.session["temp_password"] = {"uid": user.id, "password": users.reset_password_by_admin(db, user)}
    return redirect(f"/admin/clients/{user.id}")


@router.post("/{user_id}/freeze")
def freeze(
    request: Request,
    user_id: int,
    membership_id: int = Form(...),
    start: date = Form(...),
    days: int = Form(...),
    db: Session = Depends(get_db),
):
    m = db.get(Membership, membership_id)
    if m is None or m.user_id != user_id:
        raise HTTPException(404, "Абонемент не найден")
    fr = memberships.freeze(db, m, start, days)
    flash(request, f"Заморозка с {fr.start_date:%d.%m} по {fr.end_date:%d.%m}")
    return redirect(f"/admin/clients/{user_id}")


@router.post("/{user_id}/freeze/{freeze_id}/cancel")
def cancel_freeze(request: Request, user_id: int, freeze_id: int, db: Session = Depends(get_db)):
    fr = db.get(Freeze, freeze_id)
    if fr is None or fr.membership.user_id != user_id:
        raise HTTPException(404, "Заморозка не найдена")
    memberships.cancel_freeze(db, fr)
    flash(request, "Заморозка отменена")
    return redirect(f"/admin/clients/{user_id}")


@router.post("/{user_id}/personal/{package_id}/use")
def use_personal(
    request: Request,
    user_id: int,
    package_id: int,
    note: str = Form(""),
    admin: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    pkg = db.get(PersonalPackage, package_id)
    if pkg is None or pkg.user_id != user_id:
        raise HTTPException(404, "Пакет не найден")
    personal.use_session(db, pkg, admin, note)
    flash(request, f"Тренировка списана, осталось: {pkg.remaining}")
    return redirect(f"/admin/clients/{user_id}")
