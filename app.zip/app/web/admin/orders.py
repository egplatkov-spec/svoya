from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.flash import flash
from app.db.session import get_db
from app.models import Order, OrderStatus
from app.services import orders
from app.services.payments import PaymentError, PaymentProvider, get_payment_provider
from app.web.deps import back
from app.web.templating import render

router = APIRouter(prefix="/orders")
PAGE = 50


@router.get("")
def order_list(request: Request, status: str = "", page: int = 1, db: Session = Depends(get_db)):
    q = select(Order).order_by(Order.created_at.desc())
    if status in OrderStatus.__members__:
        q = q.where(Order.status == OrderStatus(status))
    page = max(1, page)
    rows = db.scalars(q.limit(PAGE + 1).offset((page - 1) * PAGE)).all()
    totals = dict(db.execute(select(Order.status, func.coalesce(func.sum(Order.amount_rub), 0)).group_by(Order.status)).all())
    return render(request, "admin/orders.html", section="orders", orders=rows[:PAGE], has_next=len(rows) > PAGE,
                  page=page, status=status, statuses=list(OrderStatus), totals=totals)


@router.post("/{order_id}/refund")
def refund(
    request: Request,
    order_id: int,
    db: Session = Depends(get_db),
    provider: PaymentProvider = Depends(get_payment_provider),
):
    order = db.get(Order, order_id)
    if order is None:
        raise HTTPException(404, "Заказ не найден")
    try:
        orders.refund(db, order, provider)
    except PaymentError as e:
        flash(request, f"Возврат не прошёл: {e}", "error")
        return back(request, "/admin/orders")
    flash(request, f"Возврат оформлен: заказ №{order.id}, {order.amount_rub} ₽")
    return back(request, "/admin/orders")
