"""Запуск сайта прямо в браузере (Pyodide) — для бесплатной публикации на GitHub Pages.

Сервер не нужен: FastAPI-приложение работает в Web Worker, база — SQLite в хранилище браузера
(IndexedDB). Страница-оболочка (pages/shell.js) пересылает сюда запросы и показывает ответы.
У каждого посетителя своя копия данных.

Используется только сборкой scripts/build_pages.py; на обычный сервер не влияет.
"""
import hashlib
import os
import sys
from contextlib import asynccontextmanager
from urllib.parse import unquote

DB_PATH = "/data/app.db"
ITERATIONS = 20_000  # в WebAssembly хеширование медленное; число итераций хранится в самом хеше


# --- В браузерном Python нет OpenSSL, а с ним и hashlib.pbkdf2_hmac: подставляем реализацию на hmac ---
_TRANS_5C = bytes(x ^ 0x5C for x in range(256))
_TRANS_36 = bytes(x ^ 0x36 for x in range(256))


def _pbkdf2_hmac(hash_name: str, password: bytes, salt: bytes, iterations: int, dklen: int | None = None) -> bytes:
    inner, outer = hashlib.new(hash_name), hashlib.new(hash_name)
    if len(password) > inner.block_size:
        password = hashlib.new(hash_name, password).digest()
    password = password.ljust(inner.block_size, b"\0")
    inner.update(password.translate(_TRANS_36))
    outer.update(password.translate(_TRANS_5C))

    def prf(msg: bytes) -> bytes:
        i, o = inner.copy(), outer.copy()
        i.update(msg)
        o.update(i.digest())
        return o.digest()

    dklen = dklen or outer.digest_size
    key, block = b"", 1
    while len(key) < dklen:
        prev = prf(salt + block.to_bytes(4, "big"))
        acc = int.from_bytes(prev, "big")
        for _ in range(iterations - 1):
            prev = prf(prev)
            acc ^= int.from_bytes(prev, "big")
        key += acc.to_bytes(inner.digest_size, "big")
        block += 1
    return key[:dklen]


if not hasattr(hashlib, "pbkdf2_hmac"):
    hashlib.pbkdf2_hmac = _pbkdf2_hmac


def configure(site_url: str, secret_key: str) -> None:
    """Настройки задаются до импорта приложения (pydantic-settings читает окружение один раз)."""
    os.environ.update(
        DEBUG="false",
        SECRET_KEY=secret_key,
        DATABASE_URL=f"sqlite:///{DB_PATH}",
        SITE_URL=site_url,
        DEMO_MODE="true",
        PAYMENT_PROVIDER="fake",
        RATE_LIMIT_ENABLED="false",
        ADMIN_PHONE="",
        ADMIN_PASSWORD="",
        TELEGRAM_BOT_TOKEN="",
        SMTP_HOST="",
    )


# --- В браузере нет потоков: синхронные обработчики FastAPI выполняем прямо в цикле событий ---

async def _run_inline(func, *args, **kwargs):
    return func(*args, **kwargs)


@asynccontextmanager
async def _cm_inline(cm):
    try:
        value = cm.__enter__()
    except Exception:
        raise
    try:
        yield value
    except BaseException as exc:
        if not cm.__exit__(type(exc), exc, exc.__traceback__):
            raise
    else:
        cm.__exit__(None, None, None)


def _patch_threadpool() -> None:
    for module in list(sys.modules.values()):
        if module is None or not getattr(module, "__name__", "").startswith(("fastapi", "starlette")):
            continue
        if hasattr(module, "run_in_threadpool"):
            module.run_in_threadpool = _run_inline
        if hasattr(module, "contextmanager_in_threadpool"):
            module.contextmanager_in_threadpool = _cm_inline


app = None


def boot(admin_phone: str, admin_password_hash: str) -> bool:
    """Импортирует приложение; при первом запуске создаёт базу, демо-данные и администратора.
    Возвращает True, если база создана заново (её нужно сохранить в IndexedDB)."""
    global app
    from app.core import security

    security._ITERATIONS = ITERATIONS

    from app.main import app as fastapi_app

    _patch_threadpool()
    app = fastapi_app

    if os.path.exists(DB_PATH):
        return False

    from app.cli import cmd_demo
    from app.db.seed import seed
    from app.db.session import Base, SessionLocal, engine
    from app.models import Role
    from app.services import users

    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed(db)
        admin = users.register(db, name="Администратор", phone=admin_phone, email=None,
                               password=security.generate_password(16), role=Role.admin)
        admin.password_hash = admin_password_hash  # в публичный код попадает только хеш пароля
        db.commit()
    cmd_demo(None)
    return True


async def handle(method: str, url: str, headers: list, body: bytes) -> tuple[int, list, bytes]:
    """Один HTTP-запрос через ASGI без сети."""
    path, _, query = url.partition("?")
    scope = {
        "type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1",
        "method": method.upper(), "scheme": "https",
        "path": unquote(path), "raw_path": path.encode(), "query_string": query.encode(), "root_path": "",
        "headers": [(k.lower().encode("latin-1"), v.encode("latin-1")) for k, v in headers]
        + [(b"host", b"svoya.local")],
        "client": ("127.0.0.1", 0), "server": ("svoya.local", 443),
    }
    sent = False

    async def receive():
        nonlocal sent
        if sent:
            return {"type": "http.disconnect"}
        sent = True
        return {"type": "http.request", "body": body, "more_body": False}

    status, out_headers, chunks = 500, [], []

    async def send(message):
        nonlocal status, out_headers
        if message["type"] == "http.response.start":
            status = message["status"]
            out_headers = [(k.decode("latin-1"), v.decode("latin-1")) for k, v in message.get("headers", [])]
        elif message["type"] == "http.response.body":
            chunks.append(message.get("body", b""))

    await app(scope, receive, send)
    return status, out_headers, b"".join(chunks)
