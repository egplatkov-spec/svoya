from dataclasses import dataclass
from datetime import time, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core import clock
from app.db.types import utcnow
from app.models import Lead, LeadStatus, Membership, Order, OrderStatus, User, Visit


@dataclass
class Dashboard:
    new_leads: int
    leads_30d: int
    active_members: int
    clients: int
    revenue_30d: int
    orders_30d: int
    visits_today: int
    expiring_7d: int


def dashboard(db: Session) -> Dashboard:
    today = clock.today()
    since = utcnow() - timedelta(days=30)
    day_start = clock.at(today, time(0, 0))
    active = select(func.count(func.distinct(Membership.user_id))).where(
        Membership.is_cancelled.is_(False), Membership.start_date <= today, Membership.end_date >= today
    )
    return Dashboard(
        new_leads=db.scalar(select(func.count()).select_from(Lead).where(Lead.status == LeadStatus.new)) or 0,
        leads_30d=db.scalar(select(func.count()).select_from(Lead).where(Lead.created_at >= since)) or 0,
        active_members=db.scalar(active) or 0,
        clients=db.scalar(select(func.count()).select_from(User)) or 0,
        revenue_30d=db.scalar(
            select(func.coalesce(func.sum(Order.amount_rub), 0)).where(Order.status == OrderStatus.paid, Order.paid_at >= since)
        ) or 0,
        orders_30d=db.scalar(
            select(func.count()).select_from(Order).where(Order.status == OrderStatus.paid, Order.paid_at >= since)
        ) or 0,
        visits_today=db.scalar(select(func.count()).select_from(Visit).where(Visit.created_at >= day_start)) or 0,
        expiring_7d=db.scalar(
            select(func.count()).select_from(Membership).where(
                Membership.is_cancelled.is_(False), Membership.end_date.between(today, today + timedelta(days=7))
            )
        ) or 0,
    )
