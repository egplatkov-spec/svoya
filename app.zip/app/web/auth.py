from fastapi import APIRouter, Depends, Form, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.csrf import verify_csrf
from app.core.errors import DomainError
from app.core.flash import flash
from app.core.ratelimit import enforce, form_limiter, login_limiter
from app.db.session import get_db
from app.models import User
from app.services import mailer, users
from app.web.deps import load_user, login_session, redirect, safe_next
from app.web.templating import render

router = APIRouter(dependencies=[Depends(load_user), Depends(verify_csrf)])


@router.get("/login")
def login_form(request: Request, next: str = "/account"):
    if getattr(request.state, "user", None):
        return redirect(safe_next(next))
    return render(request, "auth/login.html", next=safe_next(next), phone="")


@router.post("/login")
def login(
    request: Request,
    phone: str = Form(""),
    password: str = Form(""),
    next: str = Form("/account"),
    db: Session = Depends(get_db),
):
    enforce(login_limiter, request, "login")
    user = users.authenticate(db, phone, password)
    if user is None:
        return render(request, "auth/login.html", status_code=400, next=safe_next(next), phone=phone,
                      error="Неверный телефон или пароль")
    login_session(request, user)
    default = "/admin" if user.is_admin else "/account"
    return redirect(safe_next(next, default) if next != "/account" else default)


@router.get("/register")
def register_form(request: Request, next: str = "/account"):
    return render(request, "auth/register.html", next=safe_next(next), form={})


@router.post("/register")
def register(
    request: Request,
    name: str = Form(""),
    phone: str = Form(""),
    email: str = Form(""),
    password: str = Form(""),
    consent: bool = Form(False),
    next: str = Form("/account"),
    db: Session = Depends(get_db),
):
    enforce(form_limiter, request, "register")
    form = {"name": name, "phone": phone, "email": email}
    try:
        if not consent:
            raise DomainError("Нужно согласие с правилами клуба и политикой конфиденциальности")
        user = users.register(db, name=name, phone=phone, email=email, password=password)
    except DomainError as e:
        return render(request, "auth/register.html", status_code=400, next=safe_next(next), form=form, error=e.message)
    login_session(request, user)
    flash(request, f"Добро пожаловать в «{get_settings().club_name}», {user.first_name}!")
    return redirect(safe_next(next))


@router.post("/logout")
def logout(request: Request):
    request.session.clear()
    return redirect("/")


@router.get("/password/forgot")
def forgot_form(request: Request):
    return render(request, "auth/forgot.html")


@router.post("/password/forgot")
def forgot(request: Request, login: str = Form(""), db: Session = Depends(get_db)):
    enforce(form_limiter, request, "forgot")
    login = login.strip()
    user = users.get_by_phone(db, login)
    if user is None and "@" in login:
        user = db.scalar(select(User).where(User.email == login.lower()))
    if user is not None and user.email and user.is_active:
        link = f"{get_settings().site_url.rstrip('/')}/password/reset/{users.make_reset_token(user)}"
        mailer.send_email(
            user.email, f"Восстановление пароля — {get_settings().club_name}",
            f"Здравствуйте, {user.first_name}!\n\nЧтобы задать новый пароль, перейдите по ссылке (действует 1 час):\n{link}\n\n"
            "Если вы не запрашивали восстановление, просто проигнорируйте это письмо.",
        )
    # Одинаковый ответ, чтобы нельзя было узнать, зарегистрирован ли номер
    return render(request, "auth/forgot.html", sent=True)


@router.get("/password/reset/{token}")
def reset_form(request: Request, token: str, db: Session = Depends(get_db)):
    user = users.user_from_reset_token(db, token)
    return render(request, "auth/reset.html", token=token, invalid=user is None)


@router.post("/password/reset/{token}")
def reset(request: Request, token: str, password: str = Form(""), db: Session = Depends(get_db)):
    user = users.user_from_reset_token(db, token)
    if user is None:
        return render(request, "auth/reset.html", token=token, invalid=True, status_code=400)
    try:
        users.set_password(db, user, password)
    except DomainError as e:
        return render(request, "auth/reset.html", token=token, error=e.message, status_code=400)
    login_session(request, user)
    flash(request, "Пароль изменён")
    return redirect("/account")
