import re


class PhoneError(ValueError):
    pass


def normalize_phone(raw: str) -> str:
    """Приводит российский номер к виду +7XXXXXXXXXX. Принимает 8..., +7..., 7..., 9... ."""
    digits = re.sub(r"\D", "", raw or "")
    if len(digits) == 11 and digits[0] in "78":
        digits = "7" + digits[1:]
    elif len(digits) == 10 and digits[0] in "3489":
        digits = "7" + digits
    else:
        raise PhoneError("Введите номер телефона в формате +7 900 000-00-00")
    return "+" + digits


def format_phone(phone: str) -> str:
    d = re.sub(r"\D", "", phone or "")
    if len(d) != 11:
        return phone or ""
    return f"+{d[0]} ({d[1:4]}) {d[4:7]}-{d[7:9]}-{d[9:11]}"
