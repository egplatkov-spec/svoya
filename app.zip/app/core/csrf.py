"""CSRF-защита форм: токен хранится в подписанной сессии и передаётся скрытым полем csrf_token."""
import hmac
import secrets

from fastapi import HTTPException, Request

SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


def get_csrf_token(request: Request) -> str:
    token = request.session.get("csrf")
    if not token:
        token = secrets.token_urlsafe(32)
        request.session["csrf"] = token
    return token


async def verify_csrf(request: Request) -> None:
    if request.method in SAFE_METHODS:
        return
    sent = request.headers.get("x-csrf-token")
    if not sent:
        form = await request.form()  # Starlette кэширует форму, обработчик прочитает её повторно
        sent = form.get("csrf_token")
    expected = request.session.get("csrf", "")
    if not sent or not expected or not hmac.compare_digest(str(sent), expected):
        raise HTTPException(403, "Сессия устарела. Обновите страницу и попробуйте ещё раз.")
