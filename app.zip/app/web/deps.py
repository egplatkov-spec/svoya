from urllib.parse import urlsplit

from fastapi import Depends, HTTPException, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.core.csrf import get_csrf_token
from app.db.session import get_db
from app.models import User
from app.services.payments import PaymentProvider, get_payment_provider  # noqa: F401  (реэкспорт для роутов)


class LoginRequired(Exception):
    def __init__(self, next_url: str = "/account"):
        self.next_url = next_url


def load_user(request: Request, db: Session = Depends(get_db)) -> User | None:
    uid = request.session.get("uid")
    user = db.get(User, uid) if uid else None
    if user is not None and not user.is_active:
        request.session.clear()
        user = None
    request.state.user = user
    return user


def require_user(request: Request, user: User | None = Depends(load_user)) -> User:
    if user is None:
        raise LoginRequired(request.url.path)
    return user


def require_admin(user: User = Depends(require_user)) -> User:
    if not user.is_admin:
        raise HTTPException(403, "Раздел только для администраторов клуба")
    return user


def login_session(request: Request, user: User) -> None:
    """Новая сессия при входе (защита от фиксации сессии)."""
    request.session.clear()
    request.session["uid"] = user.id
    get_csrf_token(request)


def safe_next(url: str | None, default: str = "/account") -> str:
    """Только локальные пути — защита от open redirect."""
    if not url or not url.startswith("/") or url.startswith("//") or "\\" in url:
        return default
    return url


def redirect(url: str) -> RedirectResponse:
    return RedirectResponse(url, status_code=303)


def back(request: Request, default: str = "/") -> RedirectResponse:
    """Вернуть на страницу, с которой пришла форма (только тот же сайт)."""
    ref = request.headers.get("referer")
    if ref:
        parts = urlsplit(ref)
        if parts.netloc in ("", request.url.netloc):
            return redirect(safe_next(parts.path + (f"?{parts.query}" if parts.query else ""), default))
    return redirect(default)
