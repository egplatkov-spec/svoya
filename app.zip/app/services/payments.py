"""Платёжные провайдеры.

PAYMENT_PROVIDER=fake     — заглушка: оплата проходит сразу (для разработки и демо).
PAYMENT_PROVIDER=yookassa — ЮKassa: создаём платёж, отправляем покупательницу на страницу оплаты,
                            статус узнаём при возврате на сайт и из webhook-уведомлений.

Статусу из webhook не доверяем: всегда перезапрашиваем платёж через API ЮKassa.
Документация: https://yookassa.ru/developers/api
"""
import uuid
from dataclasses import dataclass
from typing import Protocol

import httpx

from app.core.config import Settings, get_settings
from app.models import Order, PaymentMethod

# Статусы платежа ЮKassa: pending, waiting_for_capture, succeeded, canceled
SUCCEEDED = "succeeded"
CANCELED = "canceled"


@dataclass
class PaymentResult:
    payment_id: str
    status: str
    confirmation_url: str | None = None


class PaymentError(Exception):
    pass


class PaymentProvider(Protocol):
    method: PaymentMethod

    def create_payment(self, order: Order, return_url: str) -> PaymentResult: ...
    def get_status(self, payment_id: str) -> str: ...
    def refund(self, order: Order) -> None: ...


class FakePaymentProvider:
    method = PaymentMethod.fake

    def create_payment(self, order: Order, return_url: str) -> PaymentResult:
        return PaymentResult(payment_id=f"fake-{uuid.uuid4()}", status=SUCCEEDED)

    def get_status(self, payment_id: str) -> str:
        return SUCCEEDED

    def refund(self, order: Order) -> None:
        return None


class YooKassaProvider:
    method = PaymentMethod.online
    API_URL = "https://api.yookassa.ru/v3"

    def __init__(self, settings: Settings, client: httpx.Client | None = None):
        if not settings.yookassa_shop_id or not settings.yookassa_secret_key:
            raise PaymentError("Не заданы YOOKASSA_SHOP_ID / YOOKASSA_SECRET_KEY")
        self.settings = settings
        self.client = client or httpx.Client(timeout=15)
        self.auth = (settings.yookassa_shop_id, settings.yookassa_secret_key)

    def _amount(self, order: Order) -> dict:
        return {"value": f"{order.amount_rub}.00", "currency": "RUB"}

    def _receipt(self, order: Order) -> dict:
        """Чек по 54-ФЗ. Нужен, если чеки формирует ЮKassa (онлайн-касса подключена к ЮKassa)."""
        customer = {"email": order.user.email} if order.user.email else {"phone": order.user.phone.lstrip("+")}
        return {
            "customer": customer,
            "items": [{
                "description": order.product.name[:128],
                "quantity": "1.00",
                "amount": self._amount(order),
                "vat_code": self.settings.yookassa_vat_code,
                "payment_mode": "full_payment",
                "payment_subject": "service",
            }],
        }

    def create_payment(self, order: Order, return_url: str) -> PaymentResult:
        body: dict = {
            "amount": self._amount(order),
            "capture": True,  # списываем сразу, без двухстадийной оплаты
            "confirmation": {"type": "redirect", "return_url": return_url},
            "description": f"Заказ №{order.id}: {order.product.name}"[:128],
            "metadata": {"order_id": str(order.id)},
        }
        if self.settings.yookassa_send_receipt:
            body["receipt"] = self._receipt(order)
        data = self._request("POST", "/payments", json=body, headers={"Idempotence-Key": f"pay-{order.id}-{uuid.uuid4()}"})
        return PaymentResult(
            payment_id=data["id"], status=data["status"],
            confirmation_url=(data.get("confirmation") or {}).get("confirmation_url"),
        )

    def get_status(self, payment_id: str) -> str:
        return self._request("GET", f"/payments/{payment_id}")["status"]

    def refund(self, order: Order) -> None:
        if not order.payment_id:
            raise PaymentError("У заказа нет платежа ЮKassa")
        body: dict = {"payment_id": order.payment_id, "amount": self._amount(order)}
        if self.settings.yookassa_send_receipt:
            body["receipt"] = self._receipt(order)
        data = self._request("POST", "/refunds", json=body, headers={"Idempotence-Key": f"refund-{order.id}"})
        if data.get("status") == CANCELED:
            raise PaymentError("ЮKassa отклонила возврат")

    def _request(self, method: str, path: str, **kwargs) -> dict:
        try:
            r = self.client.request(method, self.API_URL + path, auth=self.auth, **kwargs)
        except httpx.HTTPError as e:
            raise PaymentError(f"ЮKassa недоступна: {e}") from e
        if r.status_code >= 400:
            raise PaymentError(f"ЮKassa вернула {r.status_code}: {r.text[:300]}")
        return r.json()


def get_payment_provider() -> PaymentProvider:
    settings = get_settings()
    if settings.payment_provider == "yookassa":
        return YooKassaProvider(settings)
    return FakePaymentProvider()
