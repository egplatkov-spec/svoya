from datetime import date, datetime, time
from enum import StrEnum

from sqlalchemy import Date, Enum, ForeignKey, String, Text, Time, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.db.types import UTCDateTime, utcnow

CLASS_TAGS = {"soft": "Мягкие", "strength": "Силовые", "beginner": "Для новичков"}
WEEKDAYS = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
WEEKDAYS_SHORT = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]


class ClassType(Base):
    """Вид группового занятия: «Пилатес», «Растяжка» и т.д."""

    __tablename__ = "class_types"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    subtitle: Mapped[str] = mapped_column(String(80), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    tags: Mapped[str] = mapped_column(String(100), default="")  # ключи CLASS_TAGS через запятую
    is_active: Mapped[bool] = mapped_column(default=True)

    @property
    def tag_list(self) -> list[str]:
        return [t for t in self.tags.split(",") if t]


class ScheduleSlot(Base):
    """Еженедельное занятие: день недели + время. Конкретные даты вычисляются из него."""

    __tablename__ = "schedule_slots"

    id: Mapped[int] = mapped_column(primary_key=True)
    class_type_id: Mapped[int] = mapped_column(ForeignKey("class_types.id"))
    weekday: Mapped[int]  # 0 = понедельник
    start_time: Mapped[time] = mapped_column(Time)
    duration_min: Mapped[int] = mapped_column(default=55)
    capacity: Mapped[int] = mapped_column(default=14)
    trainer: Mapped[str] = mapped_column(String(80), default="")
    is_active: Mapped[bool] = mapped_column(default=True)

    class_type: Mapped[ClassType] = relationship(lazy="joined")


class BookingStatus(StrEnum):
    booked = "booked"
    cancelled = "cancelled"
    attended = "attended"
    missed = "missed"

    @property
    def label(self) -> str:
        return {"booked": "Записана", "cancelled": "Отменена", "attended": "Пришла", "missed": "Не пришла"}[self.value]


class Booking(Base):
    __tablename__ = "bookings"
    __table_args__ = (UniqueConstraint("user_id", "slot_id", "class_date", name="uq_booking_user_slot_date"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    slot_id: Mapped[int] = mapped_column(ForeignKey("schedule_slots.id"), index=True)
    class_date: Mapped[date] = mapped_column(Date, index=True)
    status: Mapped[BookingStatus] = mapped_column(Enum(BookingStatus, native_enum=False, length=16), default=BookingStatus.booked)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)

    slot: Mapped[ScheduleSlot] = relationship(lazy="joined")
    user: Mapped["User"] = relationship()  # noqa: F821
