"""Возврат покупательницы после оплаты и webhook-уведомления ЮKassa (без CSRF: запросы приходят извне)."""
import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.flash import flash
from app.db.session import get_db
from app.models import Order, OrderStatus
from app.services.orders import sync_order
from app.services.payments import PaymentError, PaymentProvider, get_payment_provider
from app.web.deps import load_user, redirect

log = logging.getLogger(__name__)
router = APIRouter(prefix="/payments")


@router.get("/return")
def payment_return(
    request: Request,
    order_id: int,
    db: Session = Depends(get_db),
    provider: PaymentProvider = Depends(get_payment_provider),
):
    user = load_user(request, db)
    order = db.get(Order, order_id)
    if user is None or order is None or order.user_id != user.id:
        return redirect("/account")
    try:
        sync_order(db, order, provider)
    except PaymentError:
        log.exception("Не удалось проверить платёж заказа %s", order_id)
    if order.status == OrderStatus.paid:
        flash(request, f"Оплата прошла. «{order.product.name}» уже в вашем кабинете!")
    elif order.status == OrderStatus.pending:
        flash(request, "Платёж обрабатывается. Обычно это занимает до минуты — обновите страницу.", "info")
    else:
        flash(request, "Оплата не прошла. Можно попробовать ещё раз.", "error")
    return redirect("/account")


@router.post("/yookassa/webhook")
async def yookassa_webhook(
    request: Request,
    db: Session = Depends(get_db),
    provider: PaymentProvider = Depends(get_payment_provider),
):
    """Адрес для ЛК ЮKassa: https://<домен>/payments/yookassa/webhook (события payment.succeeded, payment.canceled)."""
    try:
        payment_id = str((await request.json())["object"]["id"])
    except Exception:
        raise HTTPException(400, "Bad notification") from None
    order = db.scalar(select(Order).where(Order.payment_id == payment_id))
    if order is None:
        return {"status": "ignored"}
    try:
        sync_order(db, order, provider)  # статус берём из API, а не из тела уведомления
    except PaymentError:
        log.exception("Webhook: не удалось проверить платёж %s", payment_id)
        raise HTTPException(503, "Retry later") from None
    return {"status": "ok"}
