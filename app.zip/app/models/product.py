from enum import StrEnum

from sqlalchemy import Enum, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base


class ProductKind(StrEnum):
    membership = "membership"  # абонемент на срок: зал + группы
    personal = "personal"  # персональные тренировки поштучно / пакетом

    @property
    def label(self) -> str:
        return {"membership": "Абонемент", "personal": "Персональные тренировки"}[self.value]


class Product(Base):
    """То, что продаётся: абонемент или персональные тренировки."""

    __tablename__ = "products"

    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[ProductKind] = mapped_column(Enum(ProductKind, native_enum=False, length=16))
    name: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(Text, default="")
    price_rub: Mapped[int]
    duration_days: Mapped[int | None] = mapped_column(default=None)  # для абонемента
    freeze_days: Mapped[int] = mapped_column(default=0)  # сколько дней заморозки положено
    sessions: Mapped[int | None] = mapped_column(default=None)  # для персональных
    badge: Mapped[str] = mapped_column(String(40), default="")  # «Выгоднее всего»
    price_note: Mapped[str] = mapped_column(String(80), default="")  # «3 500 ₽ в месяц»
    is_active: Mapped[bool] = mapped_column(default=True)
    sort: Mapped[int] = mapped_column(default=0)
