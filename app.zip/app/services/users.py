import re

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.core.errors import DomainError
from app.core.phone import PhoneError, normalize_phone
from app.core.security import (
    MIN_PASSWORD_LENGTH,
    generate_password,
    hash_password,
    make_token,
    new_pass_code,
    read_token,
    verify_password,
)
from app.models import Role, User

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
RESET_PURPOSE = "password-reset"
RESET_MAX_AGE = 3600


def clean_name(name: str) -> str:
    name = " ".join((name or "").split())
    if not 2 <= len(name) <= 100:
        raise DomainError("Укажите имя (от 2 до 100 символов)")
    return name


def clean_email(email: str | None) -> str | None:
    email = (email or "").strip().lower()
    if not email:
        return None
    if len(email) > 255 or not _EMAIL_RE.match(email):
        raise DomainError("Проверьте адрес электронной почты")
    return email


def clean_phone(phone: str) -> str:
    try:
        return normalize_phone(phone)
    except PhoneError as e:
        raise DomainError(str(e)) from e


def check_password(password: str) -> str:
    if len(password or "") < MIN_PASSWORD_LENGTH:
        raise DomainError(f"Пароль должен быть не короче {MIN_PASSWORD_LENGTH} символов")
    if len(password) > 128:
        raise DomainError("Слишком длинный пароль")
    return password


def get_by_phone(db: Session, phone: str) -> User | None:
    try:
        phone = normalize_phone(phone)
    except PhoneError:
        return None
    return db.scalar(select(User).where(User.phone == phone))


def _ensure_phone_free(db: Session, phone: str, exclude_id: int | None = None) -> None:
    q = select(User.id).where(User.phone == phone)
    if exclude_id:
        q = q.where(User.id != exclude_id)
    if db.scalar(q):
        raise DomainError("Этот номер телефона уже зарегистрирован")


def register(db: Session, *, name: str, phone: str, email: str | None, password: str, role: Role = Role.client) -> User:
    name, phone, email = clean_name(name), clean_phone(phone), clean_email(email)
    check_password(password)
    _ensure_phone_free(db, phone)
    user = User(name=name, phone=phone, email=email, password_hash=hash_password(password), role=role)
    db.add(user)
    db.commit()
    return user


def create_by_admin(db: Session, *, name: str, phone: str, email: str | None) -> tuple[User, str]:
    """Клиентка пришла на ресепшен: создаём аккаунт с временным паролем."""
    password = generate_password()
    return register(db, name=name, phone=phone, email=email, password=password), password


def authenticate(db: Session, phone: str, password: str) -> User | None:
    user = get_by_phone(db, phone)
    if user is None or not user.is_active or not verify_password(password, user.password_hash):
        return None
    return user


def update_profile(db: Session, user: User, *, name: str, phone: str, email: str | None) -> User:
    name, phone, email = clean_name(name), clean_phone(phone), clean_email(email)
    _ensure_phone_free(db, phone, exclude_id=user.id)
    user.name, user.phone, user.email = name, phone, email
    db.commit()
    return user


def change_password(db: Session, user: User, old: str, new: str) -> None:
    if not verify_password(old, user.password_hash):
        raise DomainError("Текущий пароль указан неверно")
    set_password(db, user, new)


def set_password(db: Session, user: User, new: str) -> None:
    user.password_hash = hash_password(check_password(new))
    db.commit()


def reset_password_by_admin(db: Session, user: User) -> str:
    password = generate_password()
    set_password(db, user, password)
    return password


def rotate_pass_code(db: Session, user: User) -> None:
    user.pass_code = new_pass_code()
    db.commit()


# --- Сброс пароля по ссылке из письма. Токен перестаёт работать после смены пароля. ---

def make_reset_token(user: User) -> str:
    return make_token({"uid": user.id, "ph": user.password_hash[-16:]}, RESET_PURPOSE)


def user_from_reset_token(db: Session, token: str) -> User | None:
    data = read_token(token, RESET_PURPOSE, RESET_MAX_AGE)
    if not data:
        return None
    user = db.get(User, data.get("uid"))
    if user is None or not user.is_active or user.password_hash[-16:] != data.get("ph"):
        return None
    return user


def search(db: Session, query: str, limit: int = 50, offset: int = 0) -> list[User]:
    q = select(User).order_by(User.created_at.desc())
    query = (query or "").strip()
    if query:
        digits = re.sub(r"\D", "", query)
        conds = [User.name.ilike(f"%{query}%"), User.email.ilike(f"%{query}%")]
        if len(digits) >= 3:
            conds.append(User.phone.like(f"%{digits[-10:]}%"))
        q = q.where(or_(*conds))
    return list(db.scalars(q.limit(limit).offset(offset)))
