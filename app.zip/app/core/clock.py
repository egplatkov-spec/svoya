"""Единая точка получения «сейчас» в часовом поясе клуба (удобно подменять в тестах)."""
from datetime import date, datetime, time
from zoneinfo import ZoneInfo

from app.core.config import get_settings


def tz() -> ZoneInfo:
    return ZoneInfo(get_settings().timezone)


def now() -> datetime:
    return datetime.now(tz())


def today() -> date:
    return now().date()


def at(d: date, t: time) -> datetime:
    return datetime.combine(d, t, tzinfo=tz())


def local(dt: datetime) -> datetime:
    return dt.astimezone(tz())
