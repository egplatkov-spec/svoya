"""Одноразовые сообщения пользователю, переживающие редирект (хранятся в сессии)."""
from typing import Literal

from fastapi import Request

Kind = Literal["ok", "error", "info"]


def flash(request: Request, message: str, kind: Kind = "ok") -> None:
    request.session.setdefault("_flashes", []).append({"kind": kind, "text": message})
    request.session["_flashes"] = request.session["_flashes"]  # пометить сессию изменённой


def pop_flashes(request: Request) -> list[dict]:
    return request.session.pop("_flashes", []) if "session" in request.scope else []
