from datetime import datetime

from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.db.types import UTCDateTime, utcnow


class PersonalPackage(Base):
    """Купленные персональные тренировки (1 или пакет). Администратор списывает их по одной."""

    __tablename__ = "personal_packages"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), unique=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    sessions_total: Mapped[int]
    sessions_used: Mapped[int] = mapped_column(default=0)
    is_cancelled: Mapped[bool] = mapped_column(default=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)

    product: Mapped["Product"] = relationship()  # noqa: F821
    uses: Mapped[list["PersonalSessionUse"]] = relationship(
        back_populates="package", order_by="PersonalSessionUse.used_at.desc()", cascade="all, delete-orphan"
    )

    @property
    def remaining(self) -> int:
        return 0 if self.is_cancelled else max(0, self.sessions_total - self.sessions_used)


class PersonalSessionUse(Base):
    __tablename__ = "personal_session_uses"

    id: Mapped[int] = mapped_column(primary_key=True)
    package_id: Mapped[int] = mapped_column(ForeignKey("personal_packages.id", ondelete="CASCADE"), index=True)
    admin_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), default=None)
    note: Mapped[str] = mapped_column(String(200), default="")
    used_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)

    package: Mapped[PersonalPackage] = relationship(back_populates="uses")
