"""Личный кабинет клиентки."""
from datetime import date

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core import clock
from app.core.csrf import verify_csrf
from app.core.errors import DomainError
from app.core.flash import flash
from app.db.session import get_db
from app.models import Freeze, Membership, Order, User
from app.services import bookings, memberships, orders, personal, qr, users
from app.services.payments import PaymentError, PaymentProvider, get_payment_provider
from app.web.deps import redirect, require_user
from app.web.templating import render

router = APIRouter(prefix="/account", dependencies=[Depends(require_user), Depends(verify_csrf)])


@router.get("")
def dashboard(
    request: Request,
    user: User = Depends(require_user),
    db: Session = Depends(get_db),
    provider: PaymentProvider = Depends(get_payment_provider),
):
    orders.sync_pending_for_user(db, user.id, provider)
    today = clock.today()
    all_m = memberships.user_memberships(db, user.id)
    current = memberships.current_or_next(db, user.id)
    queued = [m for m in all_m if current and m.start_date > current.end_date]
    order_list = db.scalars(select(Order).where(Order.user_id == user.id).order_by(Order.created_at.desc()).limit(20)).all()
    return render(
        request, "account/dashboard.html",
        current=current, state=current.state_on(today) if current else None, queued=queued,
        packages=[p for p in personal.packages_for_user(db, user.id) if p.remaining > 0],
        upcoming=bookings.upcoming_for_user(db, user.id), orders=order_list,
        qr_svg=qr.pass_qr_svg(user.pass_code),
    )


@router.get("/pass")
def pass_page(request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    m = memberships.current_or_next(db, user.id)
    return render(request, "account/pass.html", qr_svg=qr.pass_qr_svg(user.pass_code), membership=m,
                  state=m.state_on(clock.today()) if m else None, personal_left=personal.sessions_left(db, user.id))


@router.post("/pass/rotate")
def rotate_pass(request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    users.rotate_pass_code(db, user)
    flash(request, "Выпущен новый QR-пропуск. Старый больше не действует.")
    return redirect("/account#pass")


def _own_membership(db: Session, user: User, membership_id: int) -> Membership:
    m = db.get(Membership, membership_id)
    if m is None or m.user_id != user.id:
        raise HTTPException(404, "Абонемент не найден")
    return m


@router.post("/freeze")
def freeze(
    request: Request,
    membership_id: int = Form(...),
    start: date = Form(...),
    days: int = Form(...),
    user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    m = _own_membership(db, user, membership_id)
    fr = memberships.freeze(db, m, start, days)
    flash(request, f"Абонемент заморожен с {fr.start_date:%d.%m} по {fr.end_date:%d.%m}. Новая дата окончания — {m.end_date:%d.%m.%Y}.")
    return redirect("/account#membership")


@router.post("/freeze/{freeze_id}/cancel")
def cancel_freeze(request: Request, freeze_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    fr = db.get(Freeze, freeze_id)
    if fr is None or fr.membership.user_id != user.id:
        raise HTTPException(404, "Заморозка не найдена")
    memberships.cancel_freeze(db, fr)
    flash(request, "Заморозка отменена, абонемент снова действует")
    return redirect("/account#membership")


@router.post("/orders/{order_id}/pay")
def pay_order(
    request: Request,
    order_id: int,
    user: User = Depends(require_user),
    db: Session = Depends(get_db),
    provider: PaymentProvider = Depends(get_payment_provider),
):
    order = db.get(Order, order_id)
    if order is None or order.user_id != user.id:
        raise HTTPException(404, "Заказ не найден")
    try:
        url = orders.resume_payment(db, user, order, provider)
    except PaymentError:
        flash(request, "Платёжная система временно недоступна. Попробуйте позже.", "error")
        return redirect("/account#orders")
    if url:
        return redirect(url)
    flash(request, "Заказ оплачен")
    return redirect("/account")


@router.get("/profile")
def profile(request: Request, user: User = Depends(require_user)):
    return render(request, "account/profile.html", form={"name": user.name, "phone": user.phone, "email": user.email or ""})


@router.post("/profile")
def profile_save(
    request: Request,
    name: str = Form(""),
    phone: str = Form(""),
    email: str = Form(""),
    user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    try:
        users.update_profile(db, user, name=name, phone=phone, email=email)
    except DomainError as e:
        db.rollback()
        return render(request, "account/profile.html", status_code=400,
                      form={"name": name, "phone": phone, "email": email}, error=e.message)
    flash(request, "Профиль сохранён")
    return redirect("/account/profile")


@router.post("/password")
def password_save(
    request: Request,
    old_password: str = Form(""),
    new_password: str = Form(""),
    user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    users.change_password(db, user, old_password, new_password)
    flash(request, "Пароль изменён")
    return redirect("/account/profile")
