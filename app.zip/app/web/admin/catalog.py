"""Справочники в админке: тарифы, виды занятий, расписание, вопросы, страницы."""
from fastapi import APIRouter
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import DomainError
from app.models import CLASS_TAGS, WEEKDAYS, ClassType, FaqItem, Page, Product, ProductKind, ScheduleSlot
from app.web.admin.crud import Column, Crud, Field
from app.web.templating import fmt_time, rub

YES = "✓"


def _validate_product(db: Session, p: Product) -> None:
    if p.kind == ProductKind.membership:
        if not p.duration_days:
            raise DomainError("Для абонемента укажите срок в днях")
        p.sessions = None
    else:
        if not p.sessions:
            raise DomainError("Для персональных тренировок укажите количество тренировок")
        p.duration_days, p.freeze_days = None, 0
    p.freeze_days = p.freeze_days or 0


def _class_type_choices(db: Session) -> list[tuple[str, str]]:
    return [(str(c.id), f"{c.name} — {c.subtitle}" if c.subtitle else c.name)
            for c in db.scalars(select(ClassType).order_by(ClassType.name))]


def _validate_page(db: Session, p: Page) -> None:
    import re

    if not re.fullmatch(r"[a-z0-9-]{2,60}", p.slug or ""):
        raise DomainError("Адрес страницы: латиница, цифры и дефис, от 2 символов")


products = Crud(
    slug="products", title="Тарифы", singular="Тариф", model=Product,
    intro="То, что продаётся на сайте и на ресепшене. Скрытые тарифы не показываются на сайте, но купленные остаются в силе.",
    fields=[
        Field("kind", "Тип", "select", choices=[(k.value, k.label) for k in ProductKind], coerce=ProductKind),
        Field("name", "Название", max_length=100),
        Field("price_rub", "Цена, ₽", "int", min=0, max=1_000_000),
        Field("duration_days", "Срок, дней", "int", required=False, min=1, max=1000, help="Только для абонемента"),
        Field("freeze_days", "Дней заморозки", "int", required=False, min=0, max=365, default=0, help="Только для абонемента"),
        Field("sessions", "Тренировок в пакете", "int", required=False, min=1, max=100, help="Только для персональных"),
        Field("description", "Описание", "textarea", required=False),
        Field("badge", "Плашка", required=False, max_length=40, help="Например: «Выгоднее всего»"),
        Field("price_note", "Подпись к цене", required=False, max_length=80, help="Например: «3 500 ₽ в месяц»"),
        Field("sort", "Порядок", "int", required=False, min=0, max=10000, default=0),
        Field("is_active", "Активен (показывать и продавать)", "bool"),
    ],
    columns=[
        Column("Название", lambda p: p.name), Column("Тип", lambda p: p.kind.label), Column("Цена", lambda p: rub(p.price_rub)),
        Column("Срок / тренировок", lambda p: f"{p.duration_days} дн." if p.duration_days else f"{p.sessions} шт."),
        Column("Активен", lambda p: YES if p.is_active else "—"),
    ],
    order_by=lambda: [Product.sort, Product.price_rub],
    validate=_validate_product,
)

class_types = Crud(
    slug="class-types", title="Виды занятий", singular="Вид занятия", model=ClassType,
    fields=[
        Field("name", "Название", max_length=80),
        Field("subtitle", "Подзаголовок", required=False, max_length=80, help="Например: «мягкий», «с нуля»"),
        Field("tags", "Фильтры на сайте", "multicheck", required=False, choices=list(CLASS_TAGS.items())),
        Field("description", "Описание", "textarea", required=False),
        Field("is_active", "Активно", "bool"),
    ],
    columns=[
        Column("Название", lambda c: c.name), Column("Подзаголовок", lambda c: c.subtitle),
        Column("Фильтры", lambda c: ", ".join(CLASS_TAGS[t] for t in c.tag_list if t in CLASS_TAGS)),
        Column("Активно", lambda c: YES if c.is_active else "—"),
    ],
    order_by=lambda: [ClassType.name],
)

slots = Crud(
    slug="slots", title="Сетка расписания", singular="Занятие", model=ScheduleSlot,
    intro="Еженедельное расписание. Изменения сразу видны на сайте; уже сделанные записи сохраняются.",
    fields=[
        Field("class_type_id", "Занятие", "select", choices=_class_type_choices, coerce=int),
        Field("weekday", "День недели", "select", choices=[(str(i), d) for i, d in enumerate(WEEKDAYS)], coerce=int),
        Field("start_time", "Начало", "time"),
        Field("duration_min", "Длительность, мин", "int", min=15, max=240),
        Field("capacity", "Мест", "int", min=1, max=100),
        Field("trainer", "Тренер", required=False, max_length=80),
        Field("is_active", "Активно", "bool"),
    ],
    columns=[
        Column("День", lambda s: WEEKDAYS[s.weekday]), Column("Время", lambda s: fmt_time(s.start_time)),
        Column("Занятие", lambda s: f"{s.class_type.name} ({s.class_type.subtitle})" if s.class_type.subtitle else s.class_type.name),
        Column("Мест", lambda s: s.capacity), Column("Тренер", lambda s: s.trainer or "—"),
        Column("Активно", lambda s: YES if s.is_active else "—"),
    ],
    order_by=lambda: [ScheduleSlot.weekday, ScheduleSlot.start_time],
)

faq = Crud(
    slug="faq", title="Вопросы и ответы", singular="Вопрос", model=FaqItem,
    fields=[
        Field("question", "Вопрос"),
        Field("answer", "Ответ", "textarea"),
        Field("sort", "Порядок", "int", required=False, min=0, max=10000, default=0),
        Field("is_published", "Опубликован", "bool"),
    ],
    columns=[Column("Вопрос", lambda f: f.question), Column("Опубликован", lambda f: YES if f.is_published else "—")],
    order_by=lambda: [FaqItem.sort],
)

pages = Crud(
    slug="pages", title="Страницы", singular="Страница", model=Page,
    intro="Правила, оферта, политика конфиденциальности. Текст в формате Markdown: ## заголовок, - пункт списка, **жирный**.",
    fields=[
        Field("title", "Заголовок", max_length=150),
        Field("slug", "Адрес", max_length=60, help="Страница будет доступна по адресу /p/адрес"),
        Field("body", "Текст", "markdown", required=False),
        Field("sort", "Порядок", "int", required=False, min=0, max=10000, default=0),
        Field("in_footer", "Ссылка в подвале сайта", "bool"),
        Field("is_published", "Опубликована", "bool"),
    ],
    columns=[
        Column("Заголовок", lambda p: p.title), Column("Адрес", lambda p: f"/p/{p.slug}"),
        Column("Опубликована", lambda p: YES if p.is_published else "—"),
    ],
    order_by=lambda: [Page.sort],
    validate=_validate_page,
)

CRUDS = [products, class_types, slots, faq, pages]


def register_all(router: APIRouter) -> None:
    for crud in CRUDS:
        crud.register(router)
