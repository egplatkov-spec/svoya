"""Служебные команды.

    python -m app.cli seed                         — заполнить пустую базу тарифами, расписанием, текстами
    python -m app.cli create-admin +79001234567 "Имя"  — создать/назначить администратора (пароль спросит)
    python -m app.cli demo                         — добавить демо-клиенток с абонементами (для показа)
"""
import argparse
import getpass
import sys

from app.core.errors import DomainError
from app.db.session import SessionLocal


def cmd_seed(_: argparse.Namespace) -> None:
    from app.db.seed import seed

    with SessionLocal() as db:
        seed(db)
    print("Готово: базовые данные на месте.")


def cmd_create_admin(args: argparse.Namespace) -> None:
    from app.models import Role
    from app.services import users

    password = args.password or getpass.getpass("Пароль (не короче 8 символов): ")
    with SessionLocal() as db:
        user = users.get_by_phone(db, args.phone)
        try:
            if user:
                user.role = Role.admin
                users.set_password(db, user, password)
                print(f"Пользователь {user.name} назначен администратором, пароль обновлён.")
            else:
                users.register(db, name=args.name, phone=args.phone, email=None, password=password, role=Role.admin)
                print("Администратор создан.")
        except DomainError as e:
            sys.exit(f"Ошибка: {e.message}")


def cmd_demo(_: argparse.Namespace) -> None:
    from sqlalchemy import select

    from app.models import PaymentMethod, Product, Role, User
    from app.services import leads, orders, users

    demo = [
        ("Анна Смирнова", "+79160000001", "Месяц"),
        ("Мария Иванова", "+79160000002", "Год"),
        ("Елена Козлова", "+79160000003", "8 персональных"),
        ("Ольга Петрова", "+79160000004", None),
    ]
    from app.db.seed import ensure_admin

    with SessionLocal() as db:
        ensure_admin(db)  # сначала администратор из .env, чтобы демо не заняло его место
        admin = db.scalar(select(User).where(User.role == Role.admin)) or users.register(
            db, name="Демо-администратор", phone="+79160000000", email=None, password="demo-admin-pass", role=Role.admin)
        for name, phone, product_name in demo:
            if users.get_by_phone(db, phone):
                continue
            user = users.register(db, name=name, phone=phone, email=None, password="demo-pass-123")
            if product_name:
                product = db.scalar(select(Product).where(Product.name == product_name))
                if product:
                    orders.manual_sale(db, admin, user, product, PaymentMethod.card)
        for name, phone, district in [("Ирина", "+79160000011", "Марьино"), ("Наталья", "+79160000012", "Бутово"),
                                      ("Светлана", "+79160000013", "Митино"), ("Юлия", "+79160000014", "Марьино")]:
            leads.create_lead(db, name=name, phone=phone, district=district, interests=["groups"], times=["evening"], consent=True)
    print("Демо-данные добавлены. Пароль демо-клиенток: demo-pass-123")


def main() -> None:
    parser = argparse.ArgumentParser(prog="python -m app.cli")
    sub = parser.add_subparsers(required=True)
    sub.add_parser("seed").set_defaults(func=cmd_seed)
    p = sub.add_parser("create-admin")
    p.add_argument("phone")
    p.add_argument("name", nargs="?", default="Администратор")
    p.add_argument("--password", help="лучше не указывать — спросит интерактивно")
    p.set_defaults(func=cmd_create_admin)
    sub.add_parser("demo").set_defaults(func=cmd_demo)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
