from datetime import UTC, datetime

from sqlalchemy import DateTime
from sqlalchemy.types import TypeDecorator


def utcnow() -> datetime:
    from app.core import clock  # единые часы приложения (подменяются в тестах)

    return clock.now().astimezone(UTC)


class UTCDateTime(TypeDecorator):
    """Хранит время в UTC и всегда возвращает aware-datetime (SQLite теряет таймзону)."""

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("Naive datetime is not allowed")
        return value.astimezone(UTC)

    def process_result_value(self, value, dialect):
        if value is not None and value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value
