from datetime import date, datetime, time
from pathlib import Path

from fastapi import Request
from fastapi.templating import Jinja2Templates
from markdown_it import MarkdownIt
from markupsafe import Markup
from sqlalchemy import select

from app.core import clock
from app.core.config import get_settings
from app.core.csrf import get_csrf_token
from app.core.flash import pop_flashes
from app.core.phone import format_phone
from app.db.session import SessionLocal
from app.models import CLASS_TAGS, WEEKDAYS, WEEKDAYS_SHORT, Page

MONTHS_GEN = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа",
              "сентября", "октября", "ноября", "декабря"]

_md = MarkdownIt("commonmark", {"html": False, "linkify": False, "typographer": True}).enable("table")


def rub(value: int | None) -> str:
    if value is None:
        return ""
    return f"{value:,}".replace(",", " ") + " ₽"


def fmt_date(d: date | datetime | None) -> str:
    if d is None:
        return "—"
    if isinstance(d, datetime):
        d = clock.local(d).date()
    return d.strftime("%d.%m.%Y")


def human_date(d: date) -> str:
    """«12 ноября, ср»"""
    return f"{d.day} {MONTHS_GEN[d.month - 1]}, {WEEKDAYS_SHORT[d.weekday()].lower()}"


def fmt_time(t: time | datetime | None) -> str:
    if t is None:
        return ""
    if isinstance(t, datetime):
        t = clock.local(t).time()
    return f"{t.hour}:{t.minute:02d}"


def fmt_dt(dt: datetime | None) -> str:
    if dt is None:
        return "—"
    return clock.local(dt).strftime("%d.%m.%Y %H:%M")


def plural(n: int, one: str, few: str, many: str) -> str:
    n10, n100 = abs(n) % 10, abs(n) % 100
    if n10 == 1 and n100 != 11:
        word = one
    elif 2 <= n10 <= 4 and not 12 <= n100 <= 14:
        word = few
    else:
        word = many
    return f"{n} {word}"


def markdown(text: str) -> Markup:
    return Markup(_md.render(text or ""))  # html отключён — пользовательский HTML экранируется


def _footer_pages() -> list[tuple[str, str]]:
    with SessionLocal() as db:
        rows = db.execute(
            select(Page.slug, Page.title).where(Page.is_published.is_(True), Page.in_footer.is_(True)).order_by(Page.sort)
        ).all()
    return [(s, t) for s, t in rows]


def _context(request: Request) -> dict:
    has_session = "session" in request.scope  # нет при ошибке 500 вне SessionMiddleware
    return {
        "current_user": getattr(request.state, "user", None),
        "csrf_token": get_csrf_token(request) if has_session else "",
        "flashes": pop_flashes(request) if has_session else [],
        "footer_pages": _footer_pages(),
        "today": clock.today(),
    }


def _asset_version() -> str:
    """Версия статики по времени изменения файлов — браузер не покажет устаревший CSS/JS."""
    static = Path(__file__).resolve().parent.parent / "static"
    return str(int(max((p.stat().st_mtime for p in static.rglob("*.*") if p.suffix in (".css", ".js")), default=0)))


templates = Jinja2Templates(directory=Path(__file__).resolve().parent.parent / "templates", context_processors=[_context])
env = templates.env
env.globals.update(settings=get_settings(), asset_v=_asset_version(),CLASS_TAGS=CLASS_TAGS, WEEKDAYS=WEEKDAYS, WEEKDAYS_SHORT=WEEKDAYS_SHORT)
env.filters.update(
    rub=rub, phone=format_phone, date=fmt_date, human_date=human_date, time=fmt_time, dt=fmt_dt, markdown=markdown,
)
env.globals["plural"] = plural


def render(request: Request, name: str, status_code: int = 200, **ctx):
    return templates.TemplateResponse(request, name, ctx, status_code=status_code)
