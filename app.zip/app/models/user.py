from datetime import datetime
from enum import StrEnum

from sqlalchemy import Enum, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.security import new_pass_code
from app.db.session import Base
from app.db.types import UTCDateTime, utcnow


class Role(StrEnum):
    client = "client"
    admin = "admin"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    phone: Mapped[str] = mapped_column(String(16), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(100))
    email: Mapped[str | None] = mapped_column(String(255), index=True, default=None)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[Role] = mapped_column(Enum(Role, native_enum=False, length=16), default=Role.client)
    # Код в QR-пропуске. Можно перевыпустить, если пропуск «утёк».
    pass_code: Mapped[str] = mapped_column(String(32), unique=True, index=True, default=new_pass_code)
    is_active: Mapped[bool] = mapped_column(default=True)
    admin_note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)

    @property
    def is_admin(self) -> bool:
        return self.role == Role.admin

    @property
    def first_name(self) -> str:
        return self.name.split()[0] if self.name else ""
