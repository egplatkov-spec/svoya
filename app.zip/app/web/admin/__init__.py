from fastapi import APIRouter, Depends

from app.core.csrf import verify_csrf
from app.web.admin import catalog, checkin, classes, clients, dashboard, leads, orders
from app.web.deps import require_admin

router = APIRouter(prefix="/admin", dependencies=[Depends(require_admin), Depends(verify_csrf)])
router.add_api_route("", dashboard.dashboard, methods=["GET"], name="admin_dashboard")
for module in (leads, clients, orders, checkin, classes):
    router.include_router(module.router)
catalog.register_all(router)
