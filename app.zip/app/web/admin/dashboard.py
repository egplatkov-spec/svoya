from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core import clock
from app.db.session import get_db
from app.models import Lead
from app.services import bookings, leads, stats
from app.web.templating import render


def dashboard(request: Request, db: Session = Depends(get_db)):
    today = clock.today()
    return render(
        request, "admin/dashboard.html", section="dashboard",
        stats=stats.dashboard(db),
        classes=bookings.occurrences(db, today, 1)[today],
        latest_leads=db.scalars(select(Lead).order_by(Lead.created_at.desc()).limit(8)).all(),
        votes=leads.district_votes(db),
    )
