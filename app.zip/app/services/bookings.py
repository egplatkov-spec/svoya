"""Запись на групповые занятия с ограничением числа мест."""
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core import clock
from app.core.config import get_settings
from app.core.errors import DomainError
from app.models import Booking, BookingStatus, ScheduleSlot, User
from app.services.memberships import active_on

TAKING_PLACE = (BookingStatus.booked, BookingStatus.attended)


@dataclass
class Occurrence:
    slot: ScheduleSlot
    date: date
    starts_at: datetime
    taken: int
    my_booking: Booking | None = None

    @property
    def free(self) -> int:
        return max(0, self.slot.capacity - self.taken)

    @property
    def is_past(self) -> bool:
        return self.starts_at <= clock.now()

    @property
    def can_cancel(self) -> bool:
        limit = timedelta(minutes=get_settings().booking_cancel_minutes)
        return self.my_booking is not None and self.my_booking.status == BookingStatus.booked and \
            clock.now() <= self.starts_at - limit

    @property
    def is_mine(self) -> bool:
        return self.my_booking is not None and self.my_booking.status in TAKING_PLACE


def active_slots(db: Session) -> list[ScheduleSlot]:
    return list(db.scalars(
        select(ScheduleSlot).where(ScheduleSlot.is_active.is_(True)).order_by(ScheduleSlot.weekday, ScheduleSlot.start_time)
    ).unique())


def occurrences(db: Session, start: date, days: int, user: User | None = None) -> dict[date, list[Occurrence]]:
    """Конкретные занятия на `days` дней начиная со `start`, с количеством занятых мест."""
    end = start + timedelta(days=days - 1)
    slots = [s for s in active_slots(db) if s.class_type.is_active]
    taken = dict(
        ((slot_id, d), n) for slot_id, d, n in db.execute(
            select(Booking.slot_id, Booking.class_date, func.count())
            .where(Booking.class_date.between(start, end), Booking.status.in_(TAKING_PLACE))
            .group_by(Booking.slot_id, Booking.class_date)
        )
    )
    mine: dict[tuple[int, date], Booking] = {}
    if user is not None:
        for b in db.scalars(select(Booking).where(Booking.user_id == user.id, Booking.class_date.between(start, end))).unique():
            mine[(b.slot_id, b.class_date)] = b

    result: dict[date, list[Occurrence]] = defaultdict(list)
    for i in range(days):
        d = start + timedelta(days=i)
        for s in slots:
            if s.weekday == d.weekday():
                result[d].append(Occurrence(s, d, clock.at(d, s.start_time), taken.get((s.id, d), 0), mine.get((s.id, d))))
    return {d: result.get(d, []) for d in (start + timedelta(days=i) for i in range(days))}


def book(db: Session, user: User, slot_id: int, class_date: date) -> Booking:
    s = get_settings()
    today = clock.today()
    # Блокируем строку занятия, чтобы две параллельные записи не превысили лимит (в PostgreSQL)
    slot = db.scalar(select(ScheduleSlot).where(ScheduleSlot.id == slot_id).with_for_update())
    if slot is None or not slot.is_active or not slot.class_type.is_active:
        raise DomainError("Занятие не найдено")
    if class_date.weekday() != slot.weekday:
        raise DomainError("В этот день такого занятия нет")
    if not today <= class_date <= today + timedelta(days=s.booking_days_ahead - 1):
        raise DomainError(f"Запись открыта на {s.booking_days_ahead} дней вперёд")
    if clock.at(class_date, slot.start_time) <= clock.now():
        raise DomainError("Занятие уже началось")
    if active_on(db, user.id, class_date) is None:
        raise DomainError("На эту дату нет действующего абонемента. Купите абонемент или проверьте заморозку.")

    taken = db.scalar(
        select(func.count()).select_from(Booking)
        .where(Booking.slot_id == slot.id, Booking.class_date == class_date, Booking.status.in_(TAKING_PLACE))
    )
    existing = db.scalar(
        select(Booking).where(Booking.user_id == user.id, Booking.slot_id == slot.id, Booking.class_date == class_date)
    )
    if existing and existing.status in TAKING_PLACE:
        raise DomainError("Вы уже записаны на это занятие")
    if taken >= slot.capacity:
        raise DomainError("Мест больше нет")

    if existing:
        existing.status = BookingStatus.booked
        booking = existing
    else:
        booking = Booking(user_id=user.id, slot_id=slot.id, class_date=class_date)
        db.add(booking)
    db.commit()
    return booking


def cancel(db: Session, user: User, booking_id: int) -> Booking:
    b = db.get(Booking, booking_id)
    if b is None or b.user_id != user.id:
        raise DomainError("Запись не найдена")
    if b.status != BookingStatus.booked:
        raise DomainError("Эту запись нельзя отменить")
    limit = timedelta(minutes=get_settings().booking_cancel_minutes)
    if clock.now() > clock.at(b.class_date, b.slot.start_time) - limit:
        raise DomainError(f"Отменить запись можно не позднее чем за {get_settings().booking_cancel_minutes} мин. до начала")
    b.status = BookingStatus.cancelled
    db.commit()
    return b


def upcoming_for_user(db: Session, user_id: int) -> list[Booking]:
    today = clock.today()
    rows = db.scalars(
        select(Booking).where(Booking.user_id == user_id, Booking.status == BookingStatus.booked, Booking.class_date >= today)
        .order_by(Booking.class_date)
    ).unique().all()
    now = clock.now()
    return sorted(
        (b for b in rows if clock.at(b.class_date, b.slot.start_time) > now),
        key=lambda b: (b.class_date, b.slot.start_time),
    )


def roster(db: Session, slot_id: int, class_date: date) -> list[Booking]:
    return list(db.scalars(
        select(Booking).where(Booking.slot_id == slot_id, Booking.class_date == class_date, Booking.status != BookingStatus.cancelled)
        .order_by(Booking.created_at)
    ).unique())


def set_attendance(db: Session, booking: Booking, attended: bool) -> None:
    if booking.status == BookingStatus.cancelled:
        raise DomainError("Запись отменена")
    booking.status = BookingStatus.attended if attended else BookingStatus.missed
    db.commit()
