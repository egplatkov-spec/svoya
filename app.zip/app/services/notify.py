"""Уведомления администратору в Telegram. Отправка в фоне, ошибки только логируются."""
import logging
import threading

import httpx

from app.core.config import get_settings

log = logging.getLogger(__name__)


def _send(token: str, chat_id: str, text: str) -> None:
    try:
        httpx.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text, "disable_web_page_preview": True},
            timeout=10,
        ).raise_for_status()
    except httpx.HTTPError:
        log.exception("Не удалось отправить уведомление в Telegram")


def notify_admin(text: str) -> None:
    s = get_settings()
    if not (s.telegram_bot_token and s.telegram_chat_id):
        log.info("Уведомление администратору: %s", text)
        return
    threading.Thread(target=_send, args=(s.telegram_bot_token, s.telegram_chat_id, text), daemon=True).start()
